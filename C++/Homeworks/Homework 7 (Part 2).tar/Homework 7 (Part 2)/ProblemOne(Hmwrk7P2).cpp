// Author: Alexander P. Hawkins CS1300 Spring 2018 
// Recitation: 104 Yichen Wang 
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn  
// Homework 7 - Problem 1 (Part 2)  


#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
//#include "Book.cpp"
//#include "User.cpp"
//#include "MyClass.h"
using namespace std;

//Book class
class Book //Creating a class named Book
{
  public:
    Book(string, string); //A function named Book with two perameters
    Book(); //A function named Book
    ~Book(); //A function named Book
    string getTitle(); //A function named getTitle
    void setTitle(string); //A function named setTitle
    string getAuthor(); //A function named getAuthor
    void setAuthor(string); //A function named setAuthor
  
  
  private:
    string title = "NONE"; //A variable named title with string none
    string author = "NONE"; //A variable named author with string none
    
};

Book :: Book(string Btitle, string Bauthor) //Creating the function Book
{
    title = Btitle; //variable title is a new title
    author = Bauthor; //variable author is new author
}

Book::Book() //Creating the function Book
{
    
}

Book :: ~Book() //Creating the function Book
{
    
}

void Book :: setTitle(string Btitle) //Creating the function setTitle
{
    title = Btitle; //Variabe title is new title
}

string Book :: getTitle() //Creating the function getTitle
{
    return title; //return the title
}

void Book :: setAuthor(string Bauthor) //Creating the function setAuthor
{
    author = Bauthor; //Variable author is new author
}

string Book :: getAuthor() //Creating the function getAuthor
{
    return author; //return author
}

//User class
class User //Creating a class named user
{
    private:
    string name; //Declaring string named name
    int rating[100]; //Declaring array named rating with 101 spaces
    int numRating; //Declaring int named numRating
    
    public:
    string getName(); //Declaring function string named getName
    void setName(string); //Declaring function void named setName
    int getRatings(); //Declaring function int named getRating
    void setRatings(int); //Declaring function void named setRatings
    int getNumRatings(); //Declaring function int named getNumRatings
    void setNumRatings(int); //Declaring function void named setNumRatings
    int getRatingAt(int index); //Declaring funciton int named getRatingAt
    int setRatingAt(int index, int number); //Declaring function int named setRatingAt
    
    
    User(string newName, int userRatings[], int numberRatings); //Declaring function named User with three perameters
    User(); //Declaring function named User with no perameters
};

User::User(string newName, int userRatings[], int numberRatings) //Creating function named User with the three perameters
{
    name=newName; //Variable name is new name
    numRating=numberRatings; //Variable numRating is the new number rating
    
    for(int i =0;i<100;i++) //While the computer goes through the the rating array
    {
        rating[i]=userRatings[i]; //The user Ratings are placed into the rating array
    }
}

User::User() //Creating a function named user
{
    name="NONE"; //name is none
    numRating=0; //The rating begins at 0
    
    for(int i=0;i<100;i++) //While the computer is going through the array
    {
        rating[i]=0; //The index at the rating array is 0
    }
}

string User::getName() //Creating the function getName
{
    return name; //return name
}

void User::setName(string newName) //Creating the function named setName with one perameter
{
    name=newName; //The variable name is the new given name
}

int User::getNumRatings() //Creating the function named getNumRatings
{
    return numRating; //return numRating
}

void User::setNumRatings(int numberRatings) //Creating the function named setNumRatings with one perameter
{
    numRating=numberRatings; //The variable numRating is the new number ratings
}

int User::getRatingAt(int index) //Creating a function amed getRatingAt with one perameter
{
    if(index >= numRating) //If the index is greater than or equal to the numRating
    {
        return -1000; //return -1000
    }
    
    else //else
    {
        return rating[index]; //return the index of the rating
    }
}

int User::setRatingAt(int index, int number) //Creating the variable named setRatingAt with two perameters
{
    if(index >= numRating) //If the index is greater than or equal to the numRating
    {
        return -1000; //return -1000
    }
    
    if (number!=-5 && number!=-3 && number!=0 && number!=1 && number!=3 && number!=5) //If the the given number does not equal -5,-3,0,1,3,& 5
    {
        cout<<"Invalid Input!"<<endl; //Display "Invalid input" to the user
        return -1; //return -1
    }
    
    else //else
    {
        cout<<"Success!"<<endl; //Display "Success!" to the user
        rating[index] = number; //The index of the rating array is the given number
        return 0; //return 0
    }
}

//Lower function
string lower(string word) //Declaring a function named lower with a string perameter
{
        for (int j=0; j<word.length();j++) //While the computer looks through the length of the word
    {
        if(word[j]>='A' && word[j]<='Z') //If the word in the index is any alpabet letter
        {
            word[j]=tolower(word[j]); //Turn the letter from capitalized to lowercase
    
        }    
    }
    return word; //Return the word in lower case
}

//Split function
int Split(string sentence , char seperator ,string words[],int size) //Declaring a function named split with the four perameters
{
    if(sentence.length()==0) //If the sentence is empty
        {
            return 0; //Return 0
        }
    
    string phrase=""; //Creating a variable named phrase that has an empty string
    sentence=sentence+seperator; //The sentence equals the sentence + the given seperator
    int count=0; //Creating a variable named count that starts at 0

    for (int i=0;i<sentence.length();i++) //While the computer goes through the sentence
    {
        if (sentence[i]!=seperator) //If the index in the sentence does not equal the given sperator
        {
            phrase=phrase+sentence[i]; //The phrase equals the phrase + the index of the sentence
        }
     
        if(sentence[i]==seperator) //If the index of the sentence does equal the seperator
        {
            words[count]=phrase; //The index of the word is the phrase
            count++; //The count will increase by 1
            phrase="";  //The variable 'phrase' will go back to empty
        }
    }
     return count; //Return the count
}

//Library class
class Library //Creating a Class named Library
{
	private: //Private members
	Book books[100]; //Declaring the variable book with 100 slots
	User user[100]; //Declaring the variable user with 100 slots
	int numBooks; //Declaring the variable numBooks
	int numUsers; //Declaring the variable numUsers
	int currentUser; //Declaring the variable currentUser
	
	public: //Public members
	bool login(); //Declaring a bool function named login
	void viewRating(); //Declaring a void function named viewRating
	void writeRating(); //Declaring a void function named writeRating
	void recommendBooks(); //Declaring a void function named recommendBooks
	void quitProgram(); //Declaring a void function named quitProgram
	Library (); //Declaring a function named Library
};

Library::Library() //Creating the function named Library that is in the Library class
{
	numBooks = 0; //Initializing numBooks starting at 0
	numUsers = 0; //Initializing numUsers starting at 0
	
	ifstream file_books; //Reading the file
	file_books.open("books.txt"); //Opening the file
	string line_books; //Getting each line of the book
	
	if(!file_books.is_open()) //If the file does not open
	{
		cout<<"Launch unsuccessful"<<endl<<"Error! books or ratings file could not be found."<<endl; //Display words to the user
	}
	
	cout<<"Data Loaded successfully!"<<endl; //If the file does open display more words
	
	while(getline(file_books, line_books)) //While the computer gets each line of the file and stores it with each line
	{
		string words_books[2]; //The index of the varibale words_books will be at index 2
		Split(line_books , ',' , words_books, 2); //Using the split function for the file
		string title = words_books[1]; //The title will go into the first index
		title = title.substr(0, title.length()-1); //The title will be the substring of the title
		Book book_object(lower(title),lower(words_books[0])); //The book objects will be lowercase
		books[numBooks]=book_object; //The index of books will be the book objects
		numBooks++; //The numBooks will increase by 1
	}
	
	ifstream file_UserRatings; //Reading the file
	file_UserRatings.open("ratings.txt"); //Opening the ratings file
	string line_ratings; //Declaring the string to get each line of the ratings
	
	while(getline(file_UserRatings, line_ratings)) //While the computer gets each line of the file
	{
		string words_users[2]; //Using the words user at index 2
		Split(line_ratings , ',' , words_users, 2); //Using the split function to seperate each line in the file
		string words_ratings[100]; //Using the words ratings array with index 100
		int size = 500; //Creating an int variable named size starting at 500
		int count = Split(words_users[1] , ' ' , words_ratings, size); //The count is how many splits there are
		int int_ratings[count]; //Declating int ratings using the index of the count
		
		for(int i =0; i<count-1; i++) //While the varibale i is less than the count - 1
		{
		    int x = stoi(words_ratings[i]); //The variable x is the string to integer of the words ratings at index i
		    int_ratings[i] = x; //The index of the int ratings is x
		}
		
		User user_object(words_users[0], int_ratings, size); //User objects is being used with User
		user[numUsers] = user_object; //user object is being placed into the user array
		numUsers++; //numUsers will increase by 1
	}
}

bool Library::login() //Creating the function named login in the Library class
{
    string name; //Creating a string variable named name
    char input; //Creating a character variable named input
    string copy; //Creating a string variable named copy
    cout<<"Welcome to the Library, What is your name?: "<<endl; //Display words to the user
    getline(cin,name); //get line of what the user inputs
    
    while(name=="") //While the name is empty
    {
        cout<<"You provided an empty user name, Please provide a valid user name to login or register: "<<endl; //Display words to the user
        cout<<"Enter your name again: "<<endl; //Display more words to the user
        getline(cin,name); //Get the words of what the user inputs
    }
    
    copy = name; //Copy is what the user inputs
    name = lower(name); //The name is the name in lowercase
    bool found; //The bool variable is found
    
    for(int i = 0 ; i<numUsers ; i++) //While the variable i is less than the numUsers
    {
        if (name==user[i].getName()) //If the name is the index of the user at i
        {
            found = true; //Found will be true
            currentUser = i; //Current user wil be i
            break; //Break
        }
    }
        
    if (found==true) //If found is true
    {
        cout<<"Welcome back, " << copy<<endl; //Display words to the user
    }
    
    else
    {
        cout<<"Welcome to the Library, "<<copy<<endl; //Display words to the user
        currentUser = numUsers; //The variable current User will be the num Users
        numUsers++; //Num users will increase by 1
        User user_object; //User object will be in the user class
        user_object.setName(name); //User object will be set name of the name
        user_object.setNumRatings(numBooks); //User object will be the set number ratings with the number of books
        user[numUsers] = user_object; //User objects will be placed into the user
        currentUser = numUsers; //The current users are the number of users
        numUsers++; //The number of users will increase by 1
        
    }
        
    bool run_loop=false; //Creating a bool variable named run loop that begins false
    
    while(run_loop==false) //While run loop is false
    {
        cout<<"Would you like to (v)iew your ratings, (r)ate a book, (g)et recommendations, or (q)uit?: "<<endl; //Display words to the user
        string strinput; //Declaring string input as a string
        cin >> strinput; //Store the user's input into the computer
        cin.ignore(); //Storing the user's input
            
        if (strinput=="V" || strinput=="v") //If the user inputs V or v
            {
                viewRating(); //Use the view rating function
            }
            
        else if (strinput=="R" || strinput=="r") //If the user inputs R or r
            {
                writeRating(); //Use the write rating function
            }
        
        else if (strinput=="G" || strinput=="g") //If the user inputs G or g
            {
                recommendBooks(); //Use the recommend books function
            }
            
        else if (strinput=="Q" || strinput=="q") //If the user inputs Q or q
            {
                quitProgram(); //Use the quit program function
                return true; //Return true
            }
            
        else //Else
            {
                cout<<"Please input a valid choice"<<endl; //Display words to the user
            }
    }
}
        
void Library::viewRating() //Creating the view Rating function that's in the Library class
{
    int count = 0; //Creating the variable named count starting at 0
    
    for(int j=0; j < numBooks; j++) //While the delcared variable j is less than the number of books
    {
        if(user[currentUser].getRatingAt(j)!=0) //If the cuindex at user is not 0
        {
            if(count == 0) //If the count is 0
                {
                    cout<<"Here are the books that you have rated:"<<endl; //Display words to the user
                }
                
            cout<<"Title : "<< books[j].getTitle() <<endl; //Display the title to the user
            cout<<"Rating : "<< user[currentUser].getRatingAt(j)<<endl; //Display the Rating to the user
            cout<<"------------------------------"<<endl; //Display dashes to the user
            count++; //Count will increase by 1
        }
    }
    
    if(count == 0) //If the count is 0
        {
            cout<<"You have not rated any books as yet:"<<endl; //Display words to the user
        }
}
    
void Library::writeRating() //Creating the function named write Rating that's in the Library class
{
    string whichBook; //Creating a string variable named whichBook
    int newRating; //Creating an int variable named newRating
    string whichBook1; //Creating a string variable named whichBoook1
    cout<<"Enter the name of the book that you would like to rate:"<<endl; //Display words to the user
       
    getline(cin,whichBook); //Get each line of what books the user wants
    whichBook=lower(whichBook); //Turn the words into lower case
    bool isfound = false; //Creating a bool variable named isfound that begins as false
    
    for(int r=0; r<numBooks; r++) //While the created variable r is less than the number of books
    {
        string t = books[r].getTitle();//The declared variable t is the index of the book
        
        if(t == whichBook) //If t is the user's input
            {
                cout<<"Enter your rating of the book:"<<endl; //Display words to the user
                getline(cin,whichBook1); //Get each rating of the book
                user[currentUser].setRatingAt(r,stoi(whichBook1)); //The index of user is the setRatingAt function which is string to integer
                cout<<"Thank-you. The rating for the book titled "<<whichBook<< " has been updated to "<<whichBook1<<endl; //Display words to the user
                isfound = true; //isfound is now true
            }
    }
            
    if (isfound == false) //If isfound is still false
        {
            cout<<"The book you entered does not exist in the database."<<endl; //Display words to the user
        }
        
}
    
void Library::recommendBooks() //Creating the function named recommendBooks that's in the Library class
{
    int currentbest=10000; //Creating an int variable named currentbest starting at 10000
    int mostSimiliarIndex = -1; //Creating an int variable named mostSimilarIndex starting at -1
    int count=0; //Creating an int variable named count starting at 0
    int count2=0; //Creating an int variable named count 2 starting at 0
        
    for(int i=0; i<numUsers; i++) //While the variable i is less than the number of users
    {
        int y=0; //Creating an int variable named y starting at 0
        
        for(int j=0;j<numBooks;j++) //While the variable j is less than the number of books
        {
            int z= user[currentUser].getRatingAt(j)-user[i].getRatingAt(j); //The variable z is the index of the user of the getRatingAt function subtracted
            //by the index of the user in getRatingAt of j
            int x = pow(z,2); //The delcared int variable x is z with the power of 2
            y+=x; // y is y + x
        }
        
        if(i!=currentUser && y < currentbest) //If i does not equal the current user and y is less than the current best
        {
            mostSimiliarIndex = i; //mostSimilarIndex is i
            currentbest = y; //current best is y
        }
    }
        
    for(int j=0; j<numBooks; j++) //While j is less than the number of book
    {
        if(user[mostSimiliarIndex].getRatingAt(j)>1 && user[currentUser].getRatingAt(j)==0 && count<10) //If the index of user with getRatingAt of j is less
        //than 1 and the user index (with current best's standings) with getRatingAt of j equals 0 and the count is less than 10
        {
            count++; //Count will increase by 1
            
            if(count2==0) //If the count 2 is equal to 0
            {
                cout<<"Here are some of the books that we think you would like"<<endl; //Display words to the user
            }
            
            count2++; //Count 2 will increase by 1
            cout<<books[j].getTitle()<< " by " << books[j].getAuthor() << endl; //Display the title and the author to the user
        }
    }
        
    if(count2==0) //If the count 2 equals 0
    {
        cout<<"There are no recommendations for you at present"<<endl; //Display words to the user
    }
}
    
void Library::quitProgram() //Creating the function named quitProgram that's in the Library class
{
    ofstream out_file; //Writing to the file
    out_file.open ("ratings1.txt"); //Opening the file
    
    for(int i =0; i<numUsers ; i++) //While i is less than the number of users
    {
        out_file<<user[i].getName()<<","; //Write the names to the file
        
        for(int j=0;j<user[i].getNumRatings();j++) //While j is less than the index of user with getNumberRatings
            {
                out_file<<user[i].getRatingAt(j)<<" "; //Write the ratings to the file
            }
            
        out_file << endl; //Out file will move on to the next names and ratings
    }
    
    cout<<"Data successfully saved. Goodbye!"; //Display words to the user
}

int main() //Int Main
{
    Library library1; //Calling library
	library1.login(); //Calling login in library
}