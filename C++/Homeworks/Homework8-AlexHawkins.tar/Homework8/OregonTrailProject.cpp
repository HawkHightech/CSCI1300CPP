// Author: Alexander P. Hawkins CS1300 Spring 2018 
// Recitation: 104 Yichen Wang 
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn  
// Homework 8 - Oregon Trail


#include "Date.h" //Include the Date header
#include "Party.h" //Include the Party header
#include "Player.h" //Include the Player header
#include <fstream> //Include file stream
#include <iostream> //Include io stream
using namespace std; //Using namespace std

int playersChoice() //Creating an int function named playersChoice with no perameters
{
    int beginNum; //Delcaring an int named beginNum
        
    cout << "Welcome to Oregon Trail. Where would you like to begin?" << endl; //Displaying words to the user
    cout << "1. Travel the trail" << endl; //Displaying words to the user
    cout << "2. Learn about the trail" << endl; //Displaying words to the user
    cout << "3. See the Oregon Top Ten" << endl; //Displaying words to the user
    cout << "4. End" << endl; //Displaying words to the user
    cin >> beginNum; //Stores the User's choice into the system
    return beginNum; //Returns the user's choice

}

int game() //Creating an int function named game with no perameters
{
    char allPlayersName; //Declaring char named allPlayersName
    Date *date; //Using pointers to delcare date
    Date *dateTwo; //Using pointers to declare another date
    
    cout << endl; //A space in between contents
    cout << "Many kinds of people made the trip to Oregon." << endl; //Displaying words to the user
    
    string nameOne; //Declaring string named nameOne
    string nameTwo; //Declaring string named nameTwo
    string nameThree; //Declaring string named nameThree
    string nameFour; //Declaring string named nameFour
    string nameFive; //Declaring string named nameFive
    
    cout << "Enter Player One's Name: " << endl; //Displaying words to the user
    cin >> nameOne; //Stores the user's input into the system
    Player playerOne(nameOne); //Stores the user's input into the Player class
    
    cout <<"Enter Player Two's Name: " << endl; //Displaying words to the user
    cin >> nameTwo; //Stores the user's input into the system
    Player playerTwo(nameTwo); //Stores the user's input into the Player class

    cout << "Enter Player Three's Name: " << endl; //Displaying words to the user
    cin >> nameThree; //Stores the user's input into the system
    Player playerThree(nameThree); //Stores the user's input into the Player class

    cout << "Enter Player Four's Name: " << endl; //Displaying words to the user
    cin >> nameFour; //Stores the user's input into the system
    Player playerFour(nameFour); //Stores the user's input into the Player class

    cout << "Enter Player Five's Name: " << endl; //Displaying words to the user
    cin >> nameFive; //Stores the user's input into the system
    Player playerFive(nameFive); //Stores the user's input into the Player class
    
    cout << endl; //A space in between contents

    cout << "Are these names correct?" << endl; //Displaying words to the user
    cout << playerOne.getName() << endl; //Displays the names that the user input
    cout << playerTwo.getName() << endl; //Displays the names that the user input
    cout << playerThree.getName() << endl; //Displays the names that the user input
    cout << playerFour.getName() << endl; //Displays the names that the user input
    cout << playerFive.getName() << endl; //Displays the names that the user input
    cin >> allPlayersName; //Stores the user's input into the system
    
    while (allPlayersName != 'y' || allPlayersName != 'Y') //While the user's input is not y or Y
    {
        if (allPlayersName == 'y' || allPlayersName == 'Y') //If the user's input is y or Y
        {
            break; //break the loop
        }
        
        else //else
        {
            cout << endl; //A space in between contents
            cout << "Enter Player One's Name: " << endl; //Displaying words to the user
            cin >> nameOne; //Stores the user's input into the system
            Player playerOne(nameOne); //Stores the user's input into the Player class
        
            cout <<"Enter Player Two's Name: " << endl; //Displaying words to the user
            cin >> nameTwo; //Stores the user's input into the system
            Player playerTwo(nameTwo); //Stores the user's input into the Player class
    
            cout << "Enter Player Three's Name: " << endl; //Displaying words to the user
            cin >> nameThree; //Stores the user's input into the system
            Player playerThree(nameThree); //Stores the user's input into the Player class
    
            cout << "Enter Player Four's Name: " << endl; //Displaying words to the user
            cin >> nameFour; //Stores the user's input into the system
            Player playerFour(nameFour); //Stores the user's input into the Player class
    
            cout << "Enter Player Five's Name: " << endl; //Displaying words to the user
            cin >> nameFive; //Stores the user's input into the system
            Player playerFive(nameFive); //Stores the user's input into the Player class
        
            cout << endl; //A space in between contents
    
            cout << "Are these names correct?" << endl; //Displaying words to the user
            cout << playerOne.getName() << endl; //Display the user's input
            cout << playerTwo.getName() << endl; //Display the user's input
            cout << playerThree.getName() << endl; //Display the user's input
            cout << playerFour.getName() << endl; //Display the user's input
            cout << playerFive.getName() << endl; //Display the user's input
            cin >> allPlayersName; //Stores the user's input into the system
        }
    }
    
    cout << endl; //A space in between contents
    
    int playerDate;
    cout << "It is the year 1847. Your jumping off place for Oregon is Independence, Missouri. You must decide which month to leave Independence." << endl; //Displaying words to the user
    cout << "Would you like to begin on March 28th, 1847 (03/28/1847) or any time between March 1st, 1847 (03/01/1847) & May 31st, 1847 (05/31/1847)?" << endl; //Displaying words to the user
    cout << "1. March 28th, 1847 (03/28/1847)" << endl; //Displaying words to the user
    cout << "2. I am deciding to choose my own date between March 1st, 1847 (03/01/1847) & May 31st, 1847 (05/31/1847)" << endl; //Displaying words to the user
    cin >> playerDate; //Storing the user's input into the system
    
    if (playerDate == 1) //if the user's input is 1
    {
        cout << "You are beginning on March 28, 1847 (03/28/1847)." << endl; //Displaying words to the user
        Date *date = new Date(3, 28); //The date will be the default date
    }
    
    else if (playerDate == 2) //If the user's input is 2
    {
        int playerMonth; //Delcaring int named playerMonth
        int day; //Delcaring int named day
        
        cout << endl; //A space in between contents
        
        cout << "Which month would you like to start traveling?" << endl; //Displaying words to the user
        string months[3] = {"March", "April", "May"}; //An array for the months
        for(int i = 0; i < 3; i++) //A for loop for the months
        {
            cout << i+1 << ". " << months[i] << endl; //Displaying the months
        }
        cin >> playerMonth; //Placing the user's input into the system
        
        
        if (playerMonth == 1) //If the user's input is 1
        {
            cout << endl; //A space in between contents
            cout << "Enter the day you would like to travel in the month of March: " << endl; //Displaying words to the user
            cin >> day; //Placing the user's input into the system
            if(day > 0 && day <= 31) //If the user's input is in between 0 & 31
            {
                cout << endl; //A space in between contents
                
                Date *dateTwo = new Date(3,day); //The date will be the new month + the day the user inputs
                cout << "You are beginning on March " << day << ", 1847" << " (03/" << day << "/1847)." << endl; //Displaying words to the user + the day & month
            }
            
            else //Else
            {
                while(day == 0 || day > 31) //While the user's input equals 0 or greater than 31
                {
                    cout << endl; //A space in between contents
                    cout << "Please enter a day between 0-31." << endl; //Displaying words to the user
                    cin >> day; //Placing the user's input into the system
                    if(day > 0 && day <= 31) //If the user's input is in between 0 & 31
                    {
                        cout << endl; //A space in between contents
                        cout << "You are beginning on March " << day << ", 1847" << " (03/" << day << "/1847)." << endl; //Displaying words to the user + the day & month
                        Date *dateTwo = new Date(3,day); //The date will be the new month + the day the user inputs
                        break; //break the loop
                    }
                }
            }
        }
        
        if (playerMonth == 2) //If the user's input is 2
        {
            cout << endl; //A space in between contents
            cout << "Enter the day you would like to travel in the month of April: " << endl; //Displaying words to the user
            cin >> day; //Placing the user's input into the system
            if(day > 0 && day <= 30) //If the user's input is in between 0 & 30
            {
                cout << endl; //A space in between contents
                
                Date *dateTwo = new Date(4,day); //The date will be the new month + the day the user inputs
                cout << "You are beginning on April " << day << ", 1847" << " (04/" << day << "/1847)." << endl; //Displaying words to the user + the day & month
            }
            
            else //Else
            {
                while (day == 0 || day > 30) //While the user's input is equal to 0 or greater the 30
                {
                    cout << endl; //A space in between contents
                    cout << "Please enter a day between 0-30." << endl; //Displaying words to the user
                    cin >> day; //Placing the user's input into the system
                    if (day > 0 && day <= 30) //If the user's input is in between 0 & 30
                    {
                        cout << endl; //A space in between contents
                        cout << "You are beginning on April " << day << ", 1847" << " (04/" << day << "/1847)." << endl; //Displaying words to the user + the day & month
                        Date *dateTwo = new Date(4,day); //The date will be the new month + the day the user inputs
                        break; //break the loop
                    }
                }
            }
        }
        
        if (playerMonth == 3) //If the user's input is 3
        {
            cout << endl; //A space in between contents
            cout << "Enter the day you would like to travel in the month of May: " << endl; //Displaying words to the user
            cin >> day; //Placing the user's input into the system
            if (day > 0 && day <= 31) //If the user's input is greater than 0 & less than or equal to 31
            {
                cout << endl; //A space in between contents
                
                Date *dateTwo = new Date(5,day); //The date will be the new month + the day the user inputs
                cout << "You are beginning on May " << day << ", 1847" << " (05/" << day << "/1847)." << endl; //Displaying words to the user + the day & month
            }
            
            else //Else
            {
                while (day == 0 || day > 31) //While the user's input
                {
                    cout << endl; //A space in between contents
                    cout << "Please enter a day between 0-31." << endl; //Displaying words to the user
                    cin >> day; //Placing the user's input into the system
                    if (day > 0 && day <= 31) //If the user's input is in between 0 & 31
                    {
                        cout << endl; //A space in between contents
                        cout << "You are beginning on May " << day << ", 1847" << " (05/" << day << "/1847)." << endl; //Displaying words to the user + the day & month
                        Date *dateTwo = new Date(5,day); //The date will be the new month + the day the user inputs
                        break; //break
                    }
                }
            }
        }
        
    }
    
    cout << endl; //A space in between contents
    
    cout << "Before leaving Independence you should buy equipment and supplies. You have $1200.00 in cash," << endl; //Displaying words to the user
    cout << "but you don't have to spend it all now." << endl; //Displaying words to the user
    cout << "You can buy what you need at the store." << endl; //Displaying words to the user
    cout << "Which Item would you like to buy? " << endl; //Displaying words to the user


    bool menu = true; //Declaring boolean named menu starting as true
    Party *party1 = new Party(); //Declaring party1 is Party class
    double money = 1200; //Declaring double named money starting at 1200

    while(menu) //While menu is true
    {
        string items[4] = {"Food", "Supplies", "Ammo", "Meds"}; //An array for the items
        int c; //Delcaring int named c
        int q; //Declaring int named q
        cout << "What else would you like to buy or choose 0 to leave the store: " << endl; //Displaying words to the user
        for(int i = 0; i < 4; i++) //For loop for the items
        {
            cout<< i+1 <<". "<< items[i] << endl; //Displaying the items
        }
        
        cout << "bill: " << party1->getBill() << endl; //Displaying the bill
        cin >> c; //Storing the user's input into the system

        if (c == 1) //If the user's input is 1
        {
            cout << "What quantity of food do you wish to buy? " << endl; //Displaying words to the user

            cout << "bill: " << party1->getBill() << endl; //Displaying the bill
            cin >> q; //Storing the user's input into the system
            party1->addFoodToBill(q); //Adds to the food bill
        }
        
        else if (c == 2) //If the user's input is 2
        {
            cout << "What quantity of Supplies do you wish to buy? " << endl; //Displaying words to the user

            cout << "bill: " << party1->getBill() << endl; //Displaying words to the user + the bill
            cin >> q; //Storing the user's input into the system
            party1->addSuppliesToBill(q); //adds to supplies/parts bill
        }
        
        else if(c == 3) //If the user's input is 3
        {
            cout << "What quantity of Ammo do you wish to buy? " << endl; //Displaying words to the user

            cout << "bill: " << party1->getBill() << endl; //Displaying words to the user + the bill
            cin >> q; //Storing the user's input into the system
            party1->addAmmoToBill(q); //Adds to the ammo bill
        }
        
        else if (c == 4) //If the user's input is 4
        {
            cout << "What quantity of Meds do you wish to buy? " << endl; //Displaying words to the user

            cout << "bill: " << party1->getBill() << endl; //Displaying words to the user + the bill
            cin >> q; //Storing the user's input into the system
            party1->addMedsToBill(q); //Adds to the medical bill
        }
        
        else if (c == 0) //If the user's input is 0
        {
            break; //if you want to leave the store
        }
    }
    
    char yes; //Delcaring char named yes
    bool ntrue = true; //Delcaring a boolean named ntrue initialized at true
    string line; //Declaring string named line
    string forts[16]; //Declaring an array that has string inputs named forts
    ifstream myfile("milestones.txt"); //Reading the file Milestone
    
    if(myfile.is_open()) //If the file opens
    {
        int i; //Declaring int named i
        while(getline(myfile, line)) //Reads file line by line and stores them in the string array for later use
        {
            forts[i] = line; //Forts at i is the line of the file
            i++; //i will increase by 1
        }
        myfile.close(); //The file will close
    }
    
    else //Else
    {

    }
    
    cout << "Bill: " << party1->getBill() << endl;  //Displaying words to the user + the bill
    cout <<"Money: " << money - (party1->getBill()) - 200 << endl; //Displaying words to the user - $200 from money for the wagon
    cout <<"You also had to buy a wagon so you lose an extra $200, would you like to start traveling? " << endl; //Displaying words to the user
    cin >> yes; //Storing the user's input into the system
    
    while (ntrue) //While ntrue is true
    {
        if (yes == 'y' || yes == 'Y') //If the user's input is y or Y
        {
            break; //break the loop
        }
    }
    
    int totmiles = party1->getMiles(); //Delcaring total miles into party using getMiles

    //cout << "The date is: " << date->getMonth() << "/" << date->getDay() << endl;  //Displaying words to the user + the day & month
    cout << "You are currently at " << totmiles << " miles. Would you like to start? " << endl; //Displaying words to the user + the current miles
    cin >> yes; //Storing the user's input into the system
    
    
    while(ntrue) //While ntrue is true
    {
        if (yes == 'y' || yes == 'Y') //if user's input is y or Y
        {
            totmiles = totmiles + party1->randomNumbers(70,140); //The total miles are the total miles + a random number between 70 & 140
            yes = 'n'; //yes will be n
            
            if(totmiles >= 102) //If the total miles are greater than or equal to 102
            {
                totmiles = 102; //Total miles will be 102 (First fort)
            }
            
            else //Else
            {

            }
            
        break; //break
        }
    }
    
    cout << forts[1] << endl; //Displaying the first milestone
    cout <<"You are now " << totmiles << " miles." << endl;  //Displaying words to the user + the total miles
    cout << "Would you like to continue?" << endl; //Displaying words to the user
    cin >> yes; //Storing the user's input into the system
    
    while(ntrue) //While ntrue is true
    {
        if(yes == 'y' || yes == 'Y') //if user's input is y or Y
        {
            totmiles = totmiles + party1->randomNumbers(70,140); //The total miles are the total miles + a random number between 70 & 140
            yes = 'n'; //yes will be n
            
            if(totmiles >= 102) //If the total miles are greater than or equal to 102
            {
                totmiles = 102; //Total miles will be 102 (First fort)
                cout << forts[1] << endl; //prints out fort at 1
            }
        
            else //Else
            {

            }
        break; //break the loop
        }
    }
    
    cout << "You are now " << totmiles << " miles." << endl; //Displaying words to the user + the total miles
    cout << "Would you like to continue?" << endl;  //Displaying words to the user
    return 0; //Return 0

}

void getInstructions() //Creating a void function named getInstructions()
{
    cout << "THIS PROGRAM SIMULATES A TRIP OVER THE OREGON TRAIL FROM INDEPENDENCE MISSOURI TO OREGON CITY, OREGON IN 1847." << endl; //Displaying words to the user
    cout << "YOUR FAMILY OF FIVE WILL COVER THE 2040 MILE OREGON TRAIL IN 5-6 MONTHS --- IF YOU MAKE IT ALIVE." << endl; //Displaying words to the user
    cout << "The goal is to travel from Independence, Missouri to Oregon City (2040 miles) by the end of fall (November 30th, 1847)." << endl; //Displaying words to the user
    cout << "However, the trail is arduous. Each day costs you food and health. You can hunt and rest, but you have to get there before winter!" << endl; //Displaying words to the user
    cout << "" << endl; //Creating a space in between contents
}

void topTen() //Creating a void function named topTen()
{
    cout << "1. Xvn" << endl; //Displaying words to the user
    cout << "2. Houdini" << endl; //Displaying words to the user
    cout << "3. Lou" << endl; //Displaying words to the user
    cout << "4. Gvng" << endl; //Displaying words to the user
    cout << "5. Flame" << endl; //Displaying words to the user
    cout << "6. Money" << endl; //Displaying words to the user
    cout << "7. Mvnivcc" << endl; //Displaying words to the user
    cout << "8. Fr?" << endl; //Displaying words to the user
    cout << "9. Yuh" << endl; //Displaying words to the user
    cout << "10. Xo" << endl; //Displaying words to the user
    cout << "" << endl; //Creating a space in between contents
}

int main() //The King int Main
{
    int beginNum = playersChoice(); //The user's choice is stored into beginNum
    
    while (beginNum != 4) //While the user's input is not 4
    {
        if (beginNum == 1) //If the user's input is 1
        {
            game(); //Begins the game
            break; //break
        }
        else if (beginNum == 2) //If the user's input is 2
        {
            getInstructions(); //Shows the getInstructions function
            beginNum = playersChoice(); //Asking the user to put another number in
        }
        else if (beginNum == 3) //If the user's input is 3
        {
            topTen(); //Shows the topTen function
            beginNum = playersChoice(); //Asking the user to put another number in
        }
        else if (beginNum == 4) //If the user's input is 4
        {
            break; //break
        }
        
    }

}