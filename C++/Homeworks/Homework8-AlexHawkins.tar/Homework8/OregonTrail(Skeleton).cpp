// Author: Alexander P. Hawkins CS1300 Spring 2018 
// Recitation: 104 Yichen Wang 
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn  
// Homework 8 - Oregon Trail

Instructions for Oregon Trail

Title will appear on the top
You will be given options of what the user wants to do in the system
    The Options are:
        1. Travel the trail (The game will then begin)
        2.Learn about the trail (Instructions will appear on the screen about the trail, how to play, what tools mean what, etc.
        3.See the Oregon Top Ten (Who finished the Oregon Trail with the best scores?)
        4.Turn Sound Off (The sound will turn off)
        5. Choose Management Options (What will be managed?)
        6. End (The game system will close)
        The programmer will ask "What is your choice?"
        The User will choose a number. The system will not move on until the User chooses a number (not words, letters, etc.)

If the User chooses to Travel the trail, there will be a display from the programmer saying "Many kinds of people made the trip to Oregon." at the top of the screen.
There will be options to choose which trooper you want to be in the trail.
    The Options are (The programmer displays "You May: "):
        1. Be a banker from Boston
        2. Be a carpenter from Ohio
        3. Be a farmer from Illinois
        4. Find out the differences between these options
    The programmer will ask "What is your choice?"
    The User will choose a number. The system will not move on until the User chooses a number (not words, letters, etc.)
    
The program will ask the User, "What is the first name of the wagon leader?"
    The User will insert a name and the name will be placed into the system as the wagon leader (#1 on the list)
The program will also ask the User, "What are the first names of the four other members in your party?"
    The User will insert the names and the names will be placed into the system as the other members (#2, #3, #4, & #5 on the list)
On the bottom of the screen the programmer will display to the User "(Enter Name and Press Enter)"
The programmer will ask the User "Are these Names correct?"
    If the User says No
        The User will be able to edit the names from the #1 name to the #5 name and when the User is done editing them, The programmer will ask again until the User says Yes.
    If the User says Yes
        The game will move on

The programmer will display to the User, "It is 1848. Your jumping off place for Oregon is Independence, Missouri. You must decide which month to leave Independence."
Independence, Missouri = 0 miles (the beginning)
The Programmer will give the User these Options:
    1. March
    2. April
    3. May
    4. June
    5. July
    6. Ask for Advice
    The User must choose a number between 1 - 6 to move on. The programmer will ask the User, "What is your choice?"
    
The programmer will display to the User, "Before leaving Independence, you should buy equipment and supplies. You have $1200.00 in cash, but you don't have to spend it all now."
At the bottom of the screen, the Programmer will display to the User, "Press SPACEBAR to continue"

The programmer will display to the User, "You can buy whatever you need at Matt's General Store."
At the bottom of the screen, the Programmer will display to the User, "Press SPACEBAR to continue"

The programmer will display to the User, "Hello, I'm Matt. So you're going to Oregon! I can fix you up with what you need:"
    - "A team of oxen to pull your wagon" (Displayed words to the User under ". . . what you need:")
    - "Clothing for both summer and winter" (Displayed words to the User under ". . . what you need:")
    - "Plenty of food for the trip" (Displayed words to the User under ". . . what you need:")
    - "Ammunition for your rifles" (Displayed words to the User under ". . . what you need:")
    - "Spare parts for your wagon" (Displayed words to the User under ". . . what you need:")
At the bottom of the screen, the Programmer will display to the User, "Press SPACEBAR to continue"
    Note: These are options given to the User but the User has to buy these options will the money he/she/it has
    
The programmer will display to the programmer "Matt's General Store. Indpendence, Missouri", The date at which the User choose, & the year "1848"
The programmer will display Matt's Store & The amount of what the User wants to buy each item as well as the User's Total Amount:
    1. Oxen            $0.00    |
    2. Food            $0.00    \
    3. Clothing        $0.00     ~ Note: These numbers begin at $0.00 but will rise or decrease depending on how much the User wants to spend (Decrease if the User inputs something but doesn't want it [Not able to go negative when buying])
    4. Ammunition      $0.00    /
    5. Spare Parts     $0.00    |
    ________________________
    Total Bill:        $0.00
    
    Amount you have: $1200.00
The programmer will ask the User, "Which item would you like to buy?"

If the User chooses Oxen (1)
    The programmer will display to the User, "There are 2 Oxen in a yoke; I recommend at least 3 yoke. I charge $40.00 a yoke."
    The programmer will ask the User, "How many yoke do you want?"
    The User will put however many yoke the User wants, and $40.00 will be multiplied by however many yoke the User wants and placed into the User's total bill so far.
    The amount of Oxen will be placed into the User's inventory
    At the bottom of the screen, there will be "Bill so far: " that shows the User's current bill & updates when the User spends money
The program will go back to Matt's General Store with the amount of Oxen the User wanted (in $) in the Oxen section and the Total Bill will update.
If the User attempts to buy Oxen above the amount of money they have in their pocket, display to the User, "You do not have enough money. Choose another quantity of the item."

The User will choose another number (Or press SPACEBAR to leave the store)
If the User chooses Food (2)
    The program will display to the User, "I recommend you take at least 200 pounds of food for each person in your family. I see that you have 5 people in all. You'll need flour, sugar, bacon, and coffee. My price is 20 cents a pound."
    The programmer will ask the User, "How many pounds of food do you want?"
    The User will put however many pounds of food the User wants, and $0.20 will be multiplied by however many pounds of food the User wants and placed into the User's total bill so far.
    The amount of Food will be placed into the User's inventory
    At the bottom of the screen, there will be "Bill so far: " that shows the User's current bill & updates when the User spends money
    If the User attempts to buy Food above the amount of money they have in their pocket, display to the User, "You do not have enough money. Choose another quantity of the item."
The program will go back to Matt's General Store with the amount of Food the User wanted (in $) in the Food section and the Total Bill will update.

The User will choose another number (Or press SPACEBAR to leave the store)
If the User chooses Clothing (3)
    The programmer will display to the User, "You'll need warm clothing in the mountains. I recommend taking at least 2 sets of clothing per person. Each set is $10.00."
    The programmer will ask the User, "How many sets of clothing do you want?"
    The User will put however many sets of clothing the User wants, and $10.00 will be multiplied by however many sets of clothing the User wants and placed into the User's total bill so far.
    The amount of sets of clothing will be placed into the User's inventory
    At the bottom of the screen, there will be "Bill so far: " that shows the User's current bill & updates when the User spends money
    If the User attempts to buy clothing above the amount of money they have in their pocket, display to the User, "You do not have enough money. Choose another quantity of the item."

The User will choose another number (Or press SPACEBAR to leave the store)
If the User chooses Ammunition (4)
    The programmer will display to the User, "I will sell ammunition in boxes of 20 bullets. Each box cost $2.00"
    The programmer will ask the User, "How many boxes do you want?"
    The User will put however many boxes the User wants, and $2.00 will be multiplied by however many boxes the User wants and placed into the User's total bill so far.
    If the User attempts to buy Ammunition above the amount of money they have in their pocket, display to the User, "You do not have enough money. Choose another quantity of the item."
    The amount of bullets will be placed into the User's inventory
    At the bottom of the screen, there will be "Bill so far: " that shows the User's current bill & updates when the User spends money
    
The User will choose another number (Or press SPACEBAR to leave the store)
If the User chooses Spare Parts(5)
    The programmer will display to the User, "It's a good idea to have a few spare parts for your wagon. Here are ten prices."
    The Prices will be:
        Wagon Wheel     $10 each
        Wagon Axle      $10 each
        Wagon Tongue    $10 each
    The programmer will display to the User, "How many Wagon Wheels?"
    When the User inputs a number, the total bill will change and the inventory will also change.
    The programmer will display to the User, "How many Wagon Axles?"
    When the User inputs a number, the total bill will change and the inventory will also change.
    The programmer will display to the User, "How many Wagon Tongues?"
    When the User inputs a number, the total bill will change and the inventory will also change.
    If the User attempts to buy Spare Parts above the amount of money they have in their pocket, display to the User, "You do not have enough money. Choose another quantity of the item."
At the bottom of the screen, the Programmer will display to the User, "Press SPACEBAR to leave the store"

Once the User Presses SPACEBAR (leaves the store), the User's Total Bill will be subtracted by the User's Current Money leaving him/her/it with an x amount of money left for the journey
The programmer will display to the User, "Well then, you're ready to start. Good luck! You have a long and difficult journey ahead of you."
At the bottom of the screen, the Progammer will now have "Press SPACEBAR to continue" instead of pressing Spacebar to leave the store.

----------- THE GAME HAS NOW BEGAN -----------

The programmer will display to the USer, "This is your Status Update."
    The Status Update will have:
        Current Date:       (Month[mm]/Day[dd]/Year[yyyy])
        Miles Traveled:     (In miles from the start of the trip)
        Next Landmark:      (In Miles)
        Food Available:     (In lbs. [pounds])
        Number of Bullets Available:    (An integer)
        Cash Available:     (in $)

The User will have options to:
    Stop Rest. If the User Stops to Rest:
        A random number between 1 & 3 days will be added to the total days the User has taken to complete the trail.
        The food will decrease by 3 for every day that the person rest.
    Continue on the trail. If the User chooses to continue:
        The days the User has taken will increase by 14 days (two weeks).
        The food will decrease by 3 (lbs) every day that the person continues the trail.
        The int number of miles will increase in a random number between 70 & 140.
    Hunt. If the User chooses to Hunt:
        A day (1) will be increased to the total days the User has taken to complete the trail.
        The User can encounter any one of the animals:
            Rabbit: 50% (very common animal)
            Fox: 25% (common)
            Deer: 15% (least common)
            Bear: 7% (rare)
            Moose:5% (very rare)
            These animals will come at random
            If the User encounters an animal:
                Display to the User, "You got Lucky! You encountered an _____! Do you want to Hunt? Yes(1) No (2)"
                    The program will not do anything until the User enters a 1 or 2
        If the User hunts and has less than 10 bullets in his/her/its inentory, the program will move on.
        If the User hunts and has more than 10 bullets in his/her/its inventory, the program will move to a puzzle.
            If the hunt is successful:
                The User's food will improve in their inventory as:
                    Rabbit: 2 lbs. (fixed number) & lose 10 bullets in their inventory
                    Fox: 5 lbs. (Fixed number) & lose 8 bullets in their inventory
                    Deer: Number between 30 & 55 lbs. (Random number) & lose 5 bullets in their inventory
                    Bear: Number between 100 & 250 lbs. (Random number) & lose 10 bullets in their inventory
                    Moose: Number between 300 & 600 lbs. (Random number) & lose 12 bullets in their inventory
        At the end of the distribution, the programmer will ask the User, "How well do you want to eat?":
            Poorly: 2 lbs / person
            Moderately: 3 lbs / person
            Well: 5 lbs / person
            The number will be subtracted by their total food
        If someone happens to get sick, display to the User, "Oh No! ___ is sick!" & the User has to eat well to recover.
        
Misfortunes:
If a User looses a lot of health:
    Display to the User, "Oh No! ___ is sick!" & the User has to eat well to recover.
    
A theif attacks during the night:
    Display to the User, "Oh No! Last night you got attacked by a theif!" & the food will be subtracted at a random number between 10 & 25 lbs.

One of the wagon wheels/axles/tongues breaks:
    Display to the User, "Oh No! One of your wheels are broken!" & the number of spare parts will decrease by 1 in the User's inventory.
    
Bad Weather:
    Display to the User, "Oh No! The weather is Rotten! _____! (The type of bad weathr)"
        1 day of heavy rain/hail
        3 days of storm & blizzard
        7 days for hurricane.
        Note: Food will decrease as days increase.
        
If any of these misfortunes happen:
    The probability of the User being attacked by Raiders is:
       ( ((M/100 4) 2 + 72) / ((M/100 4) 2 + 12) ) - 1 (Given equation)
        If this probability hppens:
            Display to the User, "Raiders Ahead! They look hostile!"
            The User will be given three choices:
                Run:
                    The User's inventory will be subtracted by 1 oxen, 10 lbs. of food, & 1 wagon spare parts
                Attack:
                    The puzzle much be passed to successfully win the battle.
                    If the User wins the battle:
                        The User gains 50 lbs. of food & 50 bullets in their inventory.
                    If the User loses the battle:
                        1/4 of the User's total cash is subtracted from the total cash & 50 bullets.
                    If the User chooses to surrender:
                        1/4 of the User's total cash is subtracted from the total cash.
                        
Whenever the User encounters a Puzzle:
    The User is asked to guess a number between 1 & 10
    The User has 3 tries to guess the number
    If the User wins the Puzzle (solves the puzzle):
        The User will win the Hunt or fight off the raiders
        
If the User reaches the destination before the deadline:
    Display to the User, "Great Game Leader __(name)__!"
However, Ways the User can lose the game:
    The party runs out of food.
    The party has lost all oxen.
    The party has a broken wagon and has no wagon parts left.
    The first player (the leader) dies. 
    Note: If other family members die, the leader can still push ahead, reach the destination and win the game.
    If the game ends from one of these ways:
        Display to the User, "You have died of Dysentery!" as well as the leader name, miles travelled, food remaining, cash remaining.

If the User chooses to quit:
    Display to the User, "Sucks to have the trip cut short. See ya soon!"
    The game will end.
    
    