#include "Player.h"
#include <iostream>
#include <string>

using namespace std;

Player::Player(string pName)
{
    name = pName;
    health = 5;

}

Player::~Player()
{
    //dtor
}

string Player::getName()
{
        return name;
}

void Player::setName(string name1)
{
        name = name1;
}

int Player::getHealth()
{
    return health;
}

void Player::setHealth(int phealth)
{
    health = phealth;
}

void Player::setDead(int death)
{
    dead = death;
}

bool Player::isDead()
{
    return dead;
}



void Player::rest()
{
    setHealth(5);
}
