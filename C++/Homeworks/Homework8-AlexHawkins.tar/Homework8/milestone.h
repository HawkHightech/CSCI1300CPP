// Author: Alexander P. Hawkins CS1300 Spring 2018 
// Recitation: 104 Yichen Wang 
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn  
// Homework 8 - Oregon Trail

#ifndef MILESTONE_H
#define MILESTONE_H
#include <iostream>
using namespace std;

class Milestone
{
  public:
    Milestone();
    ~Milestone();
    
    void setMilestone(string miles);
    
    string getMilestone();
    void setDistance(int d);
    int getDistance();
    
  
  
  private:
    string milestone;
    int distance;
};