// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 4 - Complete Project

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

//Create a Function called findSimilarityScore
    //The function needs to have two parameters
        //The first paramter needs to be a string for the first sequence
        //The second paramter needs to be a string for the second sequence
        //The function will not print anything

//If either of the first sequence or second sequence are not equal in the size of their lengths
    //Return -1
//If either of the first sequence or second sequence are empty
    //Return -1
//While the computer is going through the strings
    //If the letter in an index of the first sequence matches the same letter with the same index point of the second sequence
        //Bypass it because the letters match
    //If the letter in an index of the first sequence does not match the same letter with the same index point of the second sequence
        //The hamming distance will increase
//After going through both sequences, return the similarity score (With the given equation)

//Create a Function named findBestMatch
    //Function needs to have two string perameters
        //The first String perameter needs to be the genome (represents the complete set of genes in an organism)
        //The second String perameter needs to be the sequence (represents some substring or sub-sequence in the genome)
    //Function will return the similarity score of the best match found in the genome as a float
    
    //If the string of the genome or the string of the sequence is empty
        //Return -1
    //If the sequence is longer than the genome
        //Return -2
    //While you're looking through the whole genome with the sequence
        //The computer will look for the best similar score (as a float)
        //When the computer finds the best similar score
        //Return the best similar score
        
//In the Int Main function
    //Ask the user for genome one, genome two, genome three, as well as the sequence
    //If any of the user's input is empty
        //Return "Genome and sequence cannot be empty." & Return 0
    //If the sequence that the user input is greater than any of the genomes
        //Return "Sequence cannot be longer than genomes." & Ask the user to input the sequence again
    //At the end of finding the best similar score in each genome
        //Return the best genome
        

string genome_sequence; //Declaring a string named genome_sequence
string first_sequence; //Declaring a string named first_sequence

string genomeOne;//Declaring a string named genomeOne
string genomeTwo; //Declaring a string named genomeTwo
string genomeThree; //Declaring a string named genomeThree
string sequence; //Declaring a string named sequence
//string getSequence;

float Highscore_One; //Declaring a Float variable named Highscore_One
float Highscore_Two; //Declaring a Float variable named Highscore_Two
float Highscore_Three; //Declaring a Float variable named Highscore_Three

float findSimilarityScore(string genome_sequence, string first_sequence) //Function named findSimilarityScore with two string parameters
{
    float similarity_score = 0; //Float indicator for the similarity score
    float hamming_distance = 0; //When a letter in the first secquence does not match the second secquence, this number will rise
    int count = 0; //Integer Count to read through the secquences
    
    if (genome_sequence.length() != first_sequence.length() || first_sequence.length() != genome_sequence.length()) //If either length in the strings are not equal to each other
    {
        return -1; //Return -1
    }
    
    if (genome_sequence.length() == 0 || first_sequence.length() == 0) //If the first sequence or secquence is empty
    {
        return -1; //Return -1
    }
    
    for (int i = 0; i < genome_sequence.length(); i++) //A For Loop that looks through the secquence
    {
        if (genome_sequence[i] != first_sequence[i]) //If the first secquence index does not match the second secquence index
        {
            hamming_distance++; //The Hamming Distance will increase
        }
        similarity_score =((genome_sequence.length() - hamming_distance) / genome_sequence.length()); //The equation of the similarity score
    }
    
    //similarity_score = (genome_sequence.length() - hamming_distance) / genome_sequence.length(); //The equation of the similarity score
    return similarity_score; //Return the similarity score
    //return hamming_distance;
    //return first_secquence.length();
}

float findBestMatch(string genome_sequence, string first_sequence) //Creating a Float Function named findBestMatch which contains two string peramters (the genome & the sequence)
{
    int count = 0; //Declaring an integer variable named count (Starting at 0)
    
    if (genome_sequence.length() == 0 || first_sequence.length() == 0) //If the string (length) of the genome or sequence is empty
    {
        return -1; //Return -1
    }
    
    if (first_sequence.length() > genome_sequence.length()) //If the length of the sequence (substring) is longer than the genome (normal string)
    {
        return -2; //Return -2
    }
    
    float max_value = -2; //The max value will begin at -2
    
    for (int i = 0; i < genome_sequence.length() ; i++) //While the computer is looking through the genome
    {
        float total_score = findSimilarityScore(genome_sequence.substr(i,first_sequence.length()), first_sequence); //Find the total score of the best similarity score
        
        if (total_score > max_value) //The the total score is greater than the max value (Starting at -2)
        {
            max_value = total_score; //The max value is the new total score
        }
    }
    
    return max_value; //Return the max value of the best similarity score
}

int main() //Int Main
{
    //cout << findSimilarityScore("ACCT", "ACCG") << endl; //Test Case 1
    //cout << findSimilarityScore("ATTTTGADAG", "ATATTTADAA") << endl; //Test Case 2
    //cout << findSimilarityScore("", "") << endl; //Test Case 3
    
    //cout << findBestMatch("ATABADCSAS", "ACT") << endl; //Test Case 1
    //cout << findBestMatch("", "ACT") << endl; //Test Case 2
    //cout << findBestMatch("GCCA", "GCCA") << endl; //Test Case 3
    
    cout << "Please enter genome 1: " << endl; //Displaying the user to input Genome 1
    cin >> genomeOne; //Storing the User's Input into the computer
    
    cout << "Please enter genome 2: " << endl; //Displaying the user to input Genome 2
    cin >> genomeTwo; //Storing the User's Input into the computer
    
    cout << "Please enter genome 3: " << endl; //Displaying the user to input Genome 3
    cin >> genomeThree; //Storing the User's Input into the computer
    
    cout << "Please enter a sequence: " << endl; //Displaying the user to input a sequence
    cin >> first_sequence; //Storing the User's Input into the computer
    
    if (genomeOne.length() == 0 || genomeTwo.length() == 0 || genomeThree.length() == 0 || first_sequence.length() == 0) //If any of the user's input is empty
    {
        cout << "Genome and sequence cannot be empty." << endl; //Display to the user that the genome and sequence cannot be empty
        return 0; //Return 0
    }
    
    while (first_sequence.length() > genomeOne.length() || first_sequence.length() > genomeTwo.length() || first_sequence.length() > genomeThree.length()) //If the sequence is longer than any genome
    {
        cout << "Sequence cannot be longer than genomes." << endl; //Display to the user that the sequence cannot be longer
        cout << "Please enter a sequence: " << endl; //Ask the user to insert another sequence for the genomes
        cin >> first_sequence; //The user's sequence is inserted into the system
    }
    
    //if (first_sequence.length() < genomeOne.length() || first_sequence.length() < genomeTwo.length() || first_sequence.length() < genomeThree.length())
    //{
        //return 0;
    float Highscore_One = findBestMatch(genomeOne, first_sequence); //Declaring a best match for the first genome
    float Highscore_Two = findBestMatch(genomeTwo, first_sequence); //Declaring a best match for the second genome
    float Highscore_Three = findBestMatch(genomeThree, first_sequence); //Declaring a best match for the third genome
        
    //}
    
    if (Highscore_One > Highscore_Two && Highscore_One > Highscore_Three) //If Genome One is the best match
    {
        cout << "Genome 1 is the best match." << endl; //Display to the user that Genome One is the best match
    }
    
    if (Highscore_Two > Highscore_One && Highscore_Two > Highscore_Three) //If Genome Two is the best match
    {
        cout << "Genome 2 is the best match." << endl; //Display to the user that Genome Two is the best match
    }
    
    if (Highscore_Three > Highscore_Two && Highscore_Three > Highscore_One) //If Genome Three is the best match
    {
        cout << "Genome 3 is the best match." << endl; //Display to the user that Genome Three is the best match
    }
    
    if (Highscore_One == Highscore_Two && Highscore_One > Highscore_Three) //If Genomes One & Two are the best matches
    {
        cout << "Genome 1 is the best match." << endl; //Display to the user that Genome One is the best match
        cout << "Genome 2 is the best match." << endl; //Display to the user that Genome Two is the best match
    }
    
    if (Highscore_Three == Highscore_Two && Highscore_Three > Highscore_One) //If Genomes Two & Three are the best matches
    {
        cout << "Genome 2 is the best match." << endl; //Display to the user that Genome Two is the best match
        cout << "Genome 3 is the best match." << endl; //Display to the user that Genome Three is the best match
    }
    
    if (Highscore_Three == Highscore_One && Highscore_Three > Highscore_Two) //If Genomes One & Three are the best matches
    {
        cout << "Genome 1 is the best match." << endl; //Display to the user that Genome One is the best match
        cout << "Genome 3 is the best match." << endl; //Display to the user that Genome Three is the best match
    }
    
    if (Highscore_Three == Highscore_Two && Highscore_Two == Highscore_One) //If Genomes One, Two, & Three are the best matches
    {
        cout << "Genome 1 is the best match." << endl; //Display to the user that Genome One is the best match
        cout << "Genome 2 is the best match." << endl; //Display to the user that Genome Two is the best match
        cout << "Genome 3 is the best match." << endl; //Display to the user that Genome Three is the best match
    }
    

}