// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 4 - Problem 2

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

float findBestMatch(string genome_sequence, string first_sequence) //Creating a Float Function named findBestMatch which contains two string peramters (the genome & the sequence)
{
    int count = 0; //Declaring an integer variable named count (Starting at 0)
    
    if (genome_sequence.length() == 0 || first_sequence.length() == 0) //If the string (length) of the genome or sequence is empty
    {
        return -1; //Return -1
    }
    
    if (first_sequence.length() > genome_sequence.length()) //If the length of the sequence (substring) is longer than the genome (normal string)
    {
        return -2; //Return -2
    }
    
    float max_value = -2; //The max value will begin at -2
    
    for (int i = 0; i < genome_sequence.length() ; i++) //While the computer is looking through the genome
    {
        float total_score = findSimilarityScore(genome_sequence.substr(i,first_sequence.length()), first_sequence); //Find the total score of the best similarity score
        
        if (total_score > max_value) //The the total score is greater than the max value (Starting at -2)
        {
            max_value = total_score; //The max value is the new total score
        }
    }
    
    return max_value; //Return the max value of the best similarity score
}

int main()
{
    cout << findBestMatch("ATACGC", "ACT") << endl;
}