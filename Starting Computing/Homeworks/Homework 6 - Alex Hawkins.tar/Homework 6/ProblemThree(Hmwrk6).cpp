// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 6 - Problem 3

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

//Create a function named CheckWord
    //This function needs 5 input perameters
        //(1) A string word
        //(2) An array of strings correctWords
        //(3) Size of the array correctWords
        //(4) A 2D array of strings MisspelledWords[][2]
        //(5) The number of rows in the MisspelledWords array
        
    //The computer will look through the word
        //The computer will turn every letter in the word into lowercase letters
        //The word of given word will go into the correctWords array
        //Return the word
    //If the given word is found
        //Return the correct spelling of the word
        //Display "unknown" to the user

string CheckWord(string word, string correctWords[], int size, string MisspelledWords[][2], int numRows) //A declared variable named CheckWord with five input perameters
{
    for (int i = 0; i < word.length(); i++) //While the computer looks through the word
    {
        tolower(word[i]); //Turns the word into all lowercase letters
    }
    
    for (int i = 0; i < size; i++) //While the declared variable i is less than the size of the array
    {
        if (correctWords[i] == word) //The word of given word will go into the correctWords array
        {
            return word; //Return the word
        }
    }
    
    for (int i = 0; i < numRows; i++) //For the declared variable i is less than the number of rows
    {
        if (MisspelledWords[i][0] == word) //If the given word is found
        {
            return MisspelledWords[i][1]; //Return the correct spelling of the word
        }
    }
    
    return "unknown"; //Display "unknown" to the user
}