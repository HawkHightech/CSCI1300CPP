// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 6 - Problem 5

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

//Create a function named CheckFile
    //This function needs 6 input perameters
        //(1) A string inputFile
        //(2) A string outputFile (the name of the file)
        //(3) An array of strings correctWords
        //(4) Size of the array correctWords
        //(5) A 2D array of strings MisspelledWords[][2]
        //(6) The number of rows in the MisspelledWords array
        
    //Open the file for reading
    //If the file opens
        //If a line in the file is not empty
            //We will call the function CheckPhrase
        //If the file does not open
            //Display "invalid" to the user


void CheckFile(string inputFile, string outputFile, string correctWords[], int size, string MisspelledWords[][2], int numRows) //A created variable named CheckFile with six input perameters
{
    ifstream file(inputFile); //The syntax for reading the file
    string line = ""; //A delcared string variable named line that's starting blank
    
    if (file.is_open()) //If the file opens
    {
        while(getline(file, line)) //While the coputer looks through every line in the file
        {
            if (line != "") //If a line in the file is not empty
            {
                CheckPhrase(line, outputFile, correctWords, size, MisspelledWords, numRows); //Using the function CheckPhrase with CheckFile's input perameters
            }
        }
    }
    else //Else
    {
        cout << "invalid" << endl; //Display "invalid" to the user
    }
    
    return; //Return
    
}