// Author: Alexander P. Hawkins CS1300 Spring 2018 
// Recitation: 104 Yichen Wang 
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn  
// Homework 8 - Oregon Trail

#include <iostream>
#include "milestone.h"
using namespace std;

Milestone::Milestone()
{
    milestone = "";
    distance = 0;
}

Milestone::~Milestone()
{
    //Deconstructor
}

void Milestone::setMilestone(string m)
{
    milestone = m;
}

string getMilestone();
{
    return milestone;
}

void Milestone::setDistance(int d)
{
    distance = d;
}

int Milestone::getDistance()
{
    return distance;
}