// Author: Alexander P. Hawkins CS1300 Spring 2018 
// Recitation: 104 Yichen Wang 
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn  
// Homework 8 - Oregon Trail

#ifndef PARTY_H
#define PARTY_H
#include "player.h"
#include <iostream>
using namespace std;

class Party
{
    public:
        Party(int);
        ~Party();
        
        player getPlayer();
        
        bool addPlayer(string);
        
        void setNumPlayers(int);
        int getNumPlayers();
        
        int getFood();
        void setFood(int);
        
        int getMoney();
        void setMoney(int);
        
        int getAmmo();
        void setAmmo(int);
        
        int getOxen();
        void setOxen(int);
        
        int getParts();
        void setParts(int);
        
        int getClothing();
        void setClothing(int);
        
        int getMedical();
        void setMedical();
        
        void setMiles(int);
        int getMiles();
        
        void setWagonStatus(int);
        void getWagonStatus();
        
    private:
        string players[int numPlayers];
        int numPlayers;
        int food = 0;
        int money = 1000;
        int ammo = 0;
        int oxen = 0;
        int parts = 0;
        int clothing = 0;
        int medical = 0;
        int miles = 0;
        int wagonStatus;
        
};

#endif