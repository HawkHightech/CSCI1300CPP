// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 7 - Problem 4

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

//Create a function named floodMap
    //There will be three perameters in the function
        //(1) A 2-D float array (The first number will be given to the user, the second number will be fixed)
        //(2) The number of rows (Int)
        //(3) The water level (Double)
        
    //While there is a number less than the fixed number
        //If the number in the array is less than the water level
            //The computer will display *
        //If the number in the array is more than the water level
            //The computer will display _

void floodMap(double arr[][4], int num_rows, double water_level) //A created function named floodMap with the 3 peramters
{
    int count = 0; //A declared variable named count starting at 0
    
    for (int i = 0; i < num_rows; i++) //While the created variable named i is less than the number of rows
    {
        for (int n = 0; n < 4; n++) //While the created variable named n is less than the fixed number in the 2-D array
        {
            if (arr[i][n] < water_level) //If the number in the array is less than the water level
            {
                cout << "*"; //The computer will display * 
            }
            
            else if (arr[i][n] > water_level) //If the number in the array is more than the water level
            {
                cout << "_"; //The computer will display _
            }
            
        }
        
        cout << "\n"; //The computer will go to a new line
    }

}