// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 7 - Problem 2

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

//Create a function named Get Scores
    //The function need to have three peramters
        // (1) A string perameter
        // (2) An array to fill
        // (3) The max number of elements in the array
        
//While the cmoputer looks through the string
    //If there is a space in the array
        //Everything that was before the space will go into the array that we're filling
    //If there is nothing in the string
        //Return 0;
//The function will return the number of integers extraced

int GetScores(string str, int arr[], int max) //A created function named GetScores  with 3 perameters
{
    int count = 0; //A created variable named count and starting at 0
    int counter = 0; //A created variable named counter starting at 0
    
    if (str.length() == 0) //If the string length is empty
    {
        return 0; //Return 0
    }
    
    for (int i = 0; i < str.length(); i++) //While the computer is going through the string
    {
        if (str[i] == ' ' || i == (str.length()-1)) //If there is a space at any index of the string or i is equal to the length of the string-1
        {
            arr[count] = stoi (str.substr(counter, i - counter + 1)); //The array will be filled with the substring
            count++; //The count will increase by 1
            counter = i + 1; //The counter is where i is + 1
        }
    }
    
    return count; //Returns the number of integers extraced
}