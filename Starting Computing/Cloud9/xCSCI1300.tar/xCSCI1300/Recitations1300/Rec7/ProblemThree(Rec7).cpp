// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 7 - Problem 3

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

//Create a function named fillMatrix
    //Function needs to have two perameters
        //(1) A 2-D array (One that is suppose to be fillable & One fixed with a finite number)
        //(2) The number of rows
        
    //While the computer has a variable that is less than the finite number
        //The first number in the array will be added to the second number and that final number will be the number in the filled array
    

void fillMatrix(int arr[][4], int length) //A created function named fillMatrix with the 2 perameters
{
    int count = 0; //A created variable named count starting at 0
    
    for (int i = 0; i < length; i++) //While i is less that the length
    {
        for (int n = 0; n < 4; n++) //While the number n is less than the fixed number in the array
        {
            arr[i][n] = i + n; //The index of the array is the given number + the fixed number
        }
    }
}