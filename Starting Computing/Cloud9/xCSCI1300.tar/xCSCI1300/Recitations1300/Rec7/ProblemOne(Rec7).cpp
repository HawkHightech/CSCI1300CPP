// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 7 - Problem 1

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

//Create a function named Split
    //There needs to be four perameters within the function
        // (1) A string perameter
        // (2) A seperator character
        // (3) An array to fill
        // (4) The max number of elements in the array
    //The function will return the amount of substrings extracted
    
//While the computer is looking through the string
    //If there is not a seperator character in the Index of the string
        //The phrase will be the string of the index of the string + the phrase
    //If there is a seperator character in the string
        //The phrase of the string will be fill with the index of the array
        //Once there is a space filled in the array, it will go to the new slot of the array (being ready to be filled)
        //The function will return the amount of substrings extracted


int Split(string str, char chara, string arr[], int max) //Function named Split
{
    string phrase = ""; //An empty string
    int count = 0; //The count
    
    for (int i = 0; i < str.length(); i++) //While the computer is going through the string
    {
        if (str[i] != chara) //If there is not a seperator character in the Index of the string
        {
            phrase = phrase + str[i]; //The phrase will be the string of the index of the string + the phrase
        }
        
        
        else if (str[i] == chara) //If there is a seperator character in the string
        {
            arr[count] = phrase; //The phrase of the string will be fill with the index of the array
            count++; //The count will increase by 1
            phrase = ""; //The string phrase will reset
        }
        
    }
    
    if (phrase != "") //If the created variable named phrase is not empty
    {
        arr[count] = phrase; //The array we're suppose to fill is the phrase
        count++; //Count will increase by 1
    }
    
    return count; //Return the count
}