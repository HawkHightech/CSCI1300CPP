// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 6 - Problem 1

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

void printValues(int myArray[], int length)
{
    for (i = 0; i < length; i++)
    {
        cout << myArray[i] << endl;
        cout << "\n" << endl;
    }
}

int getArraySum (int myArray[], int length)
{
    count = 0
    
    for (int i = 0; i < length; i++)
    {
        total = count + myArray[i]
    }
}

int replaceNums (int myArray[], int length)
{
    
}

int main()
{
    
}