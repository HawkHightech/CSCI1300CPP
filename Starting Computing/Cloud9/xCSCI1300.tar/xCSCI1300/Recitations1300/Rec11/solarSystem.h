// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 11 - Solar System

#ifndef SOLAR_SYSTEM_H
#define SOLAR_SYSTEM_H

#include <string>
#include <iostream>
#include "planet.h"
using namespace std;

class solarSystem
{
	public:
		solarSystem(string);
		~solarSystem();

		string getName();			// return the name of the solar system
		int getNumPlanets();		// return the number of planets in the system
		bool addPlanet(string, float);	//Adds a single planet to solar system
        planet getPlanet(int);  	// return an object of planet at provided index
        float radiusDifference(planet, planet);

	private:
		int maxNumPlanets = 10; // This should be initialized to 10 in the constructor
		string systemName;
		int numPlanets;
		planet systemPlanets[10]; // array of object planet, each obj is a planet
		
};
#endif // SOLAR_SYSTEM_H
