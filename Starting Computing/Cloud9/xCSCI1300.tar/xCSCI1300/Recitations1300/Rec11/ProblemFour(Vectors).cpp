// Author: Alexander P. Hawkins CS1300 Spring 2018 
// Recitation: 104 Yichen Wang 
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn 
// Recitation 11 - Vectors 
 
#include <iostream>
#include <vector>
using namespace std;

bool is_number(const std::string& s)
{
    std::string::const_iterator it = s.begin();
    while (it != s.end() && std::isdigit(*it)) ++it; // Checks if a string is a number
    return !s.empty() && it == s.end();
}

void modifyVector(vector<int> &v)
{
    string a;
    cout<< "Please enter an integer value:"<<endl;
    cin>>a;
    while(is_number(a))
    {
        int a2 = stoi(a);
        if(v.size()==0){
            v.push_back(a2);
        }
        
        else if(a2%5==0){
            v.erase(v.begin());
        }
        else if(a2%3==0){
            v.erase(v.begin()+v.size()-1);
        }
        
        else
        {
            v.push_back(a2);
        }
        cout<< "Please enter an integer value:"<<endl;
        cin>>a;
        if(a == "q" || a == "Q")
        {
            break;
        }
        else if(!(is_number(a))){
        }
    }
}


int main()
{
    vector<int> v;
    modifyVector(v);
    int max = 0;
    int min;
    cout << "The elements in the vector are: "; // inputting 4,7,8,9,11
    for(int i = 0; i < v.size(); i++)
    {
        cout << v[i] << " ";
        if(min > v[i])
        {
            min = v[i];
        }
        
        else if(max < v[i])
        {
            max = v[i];
        }
    }
    cout << endl;
    
    cout << "Min: " << min << endl; // should get an output of min 4, and max 11
    cout << "Max: " << max << endl;
    
    return 0;
}