// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 11 - Solar System

#ifndef PLANET_H
#define PLANET_H
//#include "planet.h"
#include <string>
#include <iostream>
using namespace std;

class planet
{
	public:
		planet();
		~planet();
	
		planet(string, float);
	
		void setName(string);
		string getName();
	
		void setRadius(float);
		float getRadius();
	
	private:
		float radius;
		string name;
	
};

#endif