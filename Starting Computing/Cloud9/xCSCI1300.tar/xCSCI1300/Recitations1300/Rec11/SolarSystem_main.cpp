// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 11 - Solar System

#include <iostream>
#include "planet.h"
#include "solarSystem.h"
#include <math.h>
#include <iostream>
#include <string>

using namespace std;


/* 
    This function implements the logic to find the difference between the radius 
    of all the planets in the given solar system.
    
    Notes:
        * having more or less outputs means that your logic is not quite correct.
        * do not hard code the cout statements; use a smart logic instead.
        * use fabs() to compute the absolute value of the difference (do it either in your impementation of
          radiusDifference(planet,planet) or use it after you return the function call to radiusDifference(planet,planet)
        * your output should have the following structure:
            cout<<"Radius difference between planet " <<  <<" and planet "<< <<
                    " is => "<< <<endl;
        * for 5 planets you should have 10 outputs.
        
*/
void compareRadii(solarSystem mySolarSystem, int num_of_planets) 
{
    for (int i = 0; i < num_of_planets; i++)
    {
        for (int n = i + 1; n < num_of_planets; n++)
        {
            cout << "Radius difference between planet " << mySolarSystem.getPlanet(i).getName() << " and planet " << mySolarSystem.getPlanet(n).getName() << " is => " << mySolarSystem.radiusDifference(mySolarSystem.getPlanet(i), mySolarSystem.getPlanet(n)) << endl;
        }
    }

}


int main()
{
  
    /* 1) Ask the user to create a solar system by promting him for 5 instances
     of type Planet. You will ask the user for name and radius of each
     Planet. Each object will have to have a unique name.
    
     
     Notes and hints:
        * you can use getline() to make the process faster
        * if you use getline use a smart delimeter to process name and radius in one user input
        * make sure to check if name already exists. If it does, ask the user to enter another name.
     */
    
    int x = 0;
    bool unique = true;
    string name;
    float radius;
    
    //Logic for 1 goes here
    solarSystem sOne("SolarSystem 1");
    for (int i = 0; i < 5; i++)
    {
        cout << "Enter a Planet Name: " << endl;
        cin >> name;
        
        for (int n = 0; n < 5; n++)
        {
            if (sOne.getPlanet(n).getName() == name)
            {
                unique = false;
                break;
            }
        }
        
        while (unique == false)
        {
            string temporary = name;
            cout << "Name already used, please enter another name: ";
            cin >> name;
            
            if (name != temporary)
            {
                unique = true;
            }
        }
        
        cout << "Enter Planet Radius: ";
        cin >> radius;
        
        sOne.addPlanet(name, radius);
        
        x++;
    }
    
    int i = 0;
    int num_of_planets = sOne.getNumPlanets();
    
    if (num_of_planets < 5) 
    {
        cout<<"Your system has less than 5 planets!"<<endl;
    }
    
    while(i < num_of_planets) 
    {
        cout << "This is planet " << i << " with name: " << sOne.getPlanet(i).getName() << " and radius: " << sOne.getPlanet(i).getRadius() << endl;
        i++;
    }
    
    
    compareRadii(sOne, 5);
    compareRadii(sOne, 7);
    compareRadii(sOne, 8);
    return 0;
}
