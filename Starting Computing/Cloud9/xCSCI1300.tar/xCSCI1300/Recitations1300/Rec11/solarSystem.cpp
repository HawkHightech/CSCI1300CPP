// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 11 - Solar System

#include "solarSystem.h"
#include <math.h>


solarSystem::solarSystem(string name)
{
    systemName = name;
    numPlanets = 0;
}

solarSystem::~solarSystem()
{
    //Deconstructor
}

string solarSystem::getName()
{
    return systemName;
}

int solarSystem::getNumPlanets()
{
    return numPlanets;
}

bool solarSystem::addPlanet(string n, float r)
{
    //if (numPlanets == maxNumPlanets)
    //{
    //    return false;
    //}
    
    //else
    //{
    //    int i = 0;
    //    systemPlanets[i] = systemName;
    //    i++;
    //    return true;
    //}
    
    if(numPlanets < maxNumPlanets)
    {
        planet p(n,r);
        systemPlanets[numPlanets] = p;
        numPlanets++;

        return true;
    }
    
    else
    {
        return false;
    }

}

planet solarSystem::getPlanet(int index)
{
    return systemPlanets[index];
}

float solarSystem::radiusDifference(planet planNameOne, planet planNameTwo)
{
    float difference = planNameOne.getRadius() - planNameTwo.getRadius();
    return fabs(difference);
}
