// Author: Alexander P. Hawkins CS1300 Spring 2018 
// Recitation: 104 Yichen Wang 
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn  
// Recitation 10 - Problem 1

int bubbleSort(int arr[], int elements)
{
    bool flag = true;
    int swaps = 0;
    int comparisons = 0;
    int temp;
    //
    for(int i = 1; i < elements;i++)//while(!flag)
    {
        flag = true;
        for (int n = 0; n < (elements - i); n++)
        {
            comparisons++;
            
            if (arr[n] > arr[n+1])
            {
                temp = arr[n];
                arr[n] = arr[n+1];
                arr[n+1] = temp;
                swaps++;
                flag = false;
            }
            
        }
        if (flag)
        {
            break;
        }
        
    }
    
    cout << "Bubble Sort:" << endl;
    
    for (int i = 0; i < elements; i++)
    {
        cout << arr[i] << " ";
    }
    
    cout << endl;
    cout << "Number of comparisons: " << comparisons << endl;
    cout << "Number of swaps: " << swaps << endl;

}