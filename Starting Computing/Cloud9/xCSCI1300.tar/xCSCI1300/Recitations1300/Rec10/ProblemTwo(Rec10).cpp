// Author: Alexander P. Hawkins CS1300 Spring 2018 
// Recitation: 104 Yichen Wang 
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn  
// Recitation 10 - Problem 2

int cocktailSort(int arr[], int elements)
{
    bool flag = false;
    int swaps = 0;
    int comparisons = 0;
    int temp;
    int i = 1;
    int x = 0;
    //
    while(!flag)
    {
        flag = true;
        for (int n = x; n < (elements - i); n++)
        {
            comparisons++;
            
            if (arr[n] > arr[n+1])
            {
                temp = arr[n];
                arr[n] = arr[n+1];
                arr[n+1] = temp;
                swaps++;
                flag = false;
            }
            
        }
        if (flag)
        {
            break;
        }
        i++;
        flag = true;
        for (int j = (elements - i); j > x; j--)
        {
            comparisons++;
            if (arr[j] < arr[j-1])
            {
                temp = arr[j];
                arr[j] = arr[j-1];
                arr[j-1] = temp;
                swaps++;
                flag = false;
            }
        }
        x++;
    }
    
    cout << "Cocktail Sort:" << endl;
    
    for (int i = 0; i < elements; i++)
    {
        cout << arr[i] << " ";
    }
    
    cout << endl;
    cout << "Number of comparisons: " << comparisons << endl;
    cout << "Number of swaps: " << swaps << endl;

}