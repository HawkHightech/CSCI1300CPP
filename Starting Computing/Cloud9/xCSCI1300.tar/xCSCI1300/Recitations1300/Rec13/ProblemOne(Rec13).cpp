#import math

def print_param(kudi):
    print(kudi)