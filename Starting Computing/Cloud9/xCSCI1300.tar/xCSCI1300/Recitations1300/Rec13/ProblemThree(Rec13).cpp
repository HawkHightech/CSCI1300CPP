def fizz_buzz(n):
    for i in range(n+1):
        if (i % 3 == 0 and i % 5 != 0):
            print("Fizz")
        elif (i % 5 == 0 and i % 3 != 0):
            print ("Buzz")
        elif (i % 3 == 0 and i % 5 == 0 and i != 0):
            print ("FizzBuzz")
        elif (i % 3 != 0 and i % 5 != 0):
            print (i)
        else:
            print (i)