def odd_or_even(kudi):
    if kudi % 2 == 0:
        print("even")
    else:
        print("odd")