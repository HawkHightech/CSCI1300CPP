// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 9 - Problem 4

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
//#include "MyClass.h"
using namespace std;

class battleShip
{
	public:
		battleShip(string);
		~battleShip();
		void setShipName(string);
		string getShipName();
		void setSize(int);
		int getSize();
		void recordHit();	// Increments the hits data member
		bool isSunk();	// returns true if hits is greater than equal to size
	private:
		string name;
		int size = -1;
		int hits;
};

battleShip :: battleShip(string ship)
{
    name = ship;
}

battleShip :: ~battleShip()
{
    
}

void battleShip :: setShipName(string sname)
{
    name = sname;
}

string battleShip :: getShipName()
{
    return name;
}

void battleShip :: setSize(int s)
{
    size = s;
}

int battleShip :: getSize()
{
    return size;
}

void battleShip :: recordHit()
{
    hits++;
    cout << name << " has been hit " << hits << " times." << endl;
}

bool battleShip :: isSunk()
{
    if(hits >= size)
    {
        cout << name << " has been sunk." << endl;    
    }
    
    return hits >= size;
    
}