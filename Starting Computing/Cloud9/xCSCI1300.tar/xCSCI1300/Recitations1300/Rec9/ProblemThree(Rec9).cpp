// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 9 - Problem 3

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
//#include "MyClass.h"
using namespace std;

class Robot
{
    public:
        int getX(void);
        int getY(void);
        char getHeading(void);
        void setX(int NewX);
        void setY(int NewY);
        void setHeading(char NewHeading);
        Robot(int start_x,int start_y,char start_heading);
        
        void turnLeft();
        void turnRight();
        void moveForward();
        
    private:
        int x;
        int y;
        char heading;
    
};

Robot::Robot(int start_x,int start_y,char start_heading)
{
    x = start_x;
    y = start_y;
    heading = start_heading;
}

int Robot::getX()
{
    return x;
}

int Robot::getY()
{
    return y;
}

char Robot::getHeading()
{
    return heading;
}

void Robot::setX(int NewX)
{
    x = NewX;
}

void Robot::setY(int NewY)
{
    y = NewY;
}

void Robot::setHeading(char NewHeading)
{
    heading = NewHeading;
}

void Robot::turnLeft()
{
    if (heading == 'N')
    {
        heading = 'W';
    }
    
    else if (heading == 'W')
    {
        heading = 'S';
    }
    
    else if (heading == 'S')
    {
        heading = 'E';
    }
    
    else if (heading == 'E')
    {
        heading = 'N';
    }

}

void Robot::turnRight()
{
    if (heading == 'N')
    {
        heading = 'E';
    }
    
    else if (heading == 'E')
    {
        heading = 'S';
    }
    
    else if (heading == 'S')
    {
        heading = 'W';
    }
    
    else if (heading == 'W')
    {
        heading = 'N';
    }

}

void Robot::moveForward()
{
    if (heading == 'N')
    {
        y++;
    }
    
    else if (heading == 'S')
    {
        y--;
    }
    
    else if (heading == 'E')
    {
        x++;
    }
    
    else if (heading == 'W')
    {
        x--;
    }
}