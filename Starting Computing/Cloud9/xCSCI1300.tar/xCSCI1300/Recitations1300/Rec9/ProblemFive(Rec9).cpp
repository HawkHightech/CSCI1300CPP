// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 9 - Problem 5

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
//#include "MyClass.h"
using namespace std;

void play()
{
    battleShip ship_one("Destroyer");
    battleShip ship_two("Carrier");
    battleShip ship_three("Cruiser");
    
	//TODO: Declare 3 instances/objects of the battleship class: Destroyer Carrier Cruiser
    ship_one.setSize(3);
    ship_two.setSize(5);
    ship_three.setSize(2);

	//TOD0: Give the ships a size: Destroyer-3 Carrier-5 Cruiser-2
	// you will need to call the appropriate methods
    

	
        // Once you have this running for one, expand this while loop to include the
	// other two instances. Have the while loop end when all three ships have been sunk.

        // Make your while condition while ship one is not sunk OR ship two is not sunk OR ship three is not sunk.



	while(ship_one.isSunk() == false || ship_two.isSunk() == false || ship_three.isSunk() == false)
	{
		ship_one.recordHit();
		ship_two.recordHit();
		ship_three.recordHit();
	}
}