// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 9 - Problem 1

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
//#include "MyClass.h"
using namespace std;

class Robot
{
    public:
        int x;
        int y;
        char heading;
        Robot(int start_x,int start_y,char start_heading);
};

Robot::Robot(int start_x,int start_y,char start_heading)
        
        {
            x = start_x;
            y = start_y;
            heading = start_heading;
        }