// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 9 - Problem 2

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
//#include "MyClass.h"
using namespace std;

class Robot
{
    public:
        int getX(void);
        int getY(void);
        char getHeading(void);
        void setX(int NewX);
        void setY(int NewY);
        void setHeading(char NewHeading);
        Robot(int start_x,int start_y,char start_heading);
        
    private:
        int x;
        int y;
        char heading;
    
};

Robot::Robot(int start_x,int start_y,char start_heading)
{
    x = start_x;
    y = start_y;
    heading = start_heading;
}

int Robot::getX()
{
    return x;
}

int Robot::getY()
{
    return y;
}

char Robot::getHeading()
{
    return heading;
}

void Robot::setX(int NewX)
{
    x = NewX;
}

void Robot::setY(int NewY)
{
    y = NewY;
}

void Robot::setHeading(char NewHeading)
{
    heading = NewHeading;
}