// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 8 - Problem 2

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
using namespace std;

//Create a function named fileLoadWrite
    //This function needs only one perameter input
        //(1) The file name that we are writing to
    
    //The file needs to open in a writing syntax
        //If the file does not open
            //Return 0
        //If the file does open
            //We want to take the square of the numbers between 1 & 10
                // Ex. 1^2 = 1, 2^2 = 4, 3^2 = 9 etc.
                // Equation = number * itself
                //All of these numbers need to be on the same line
        //The file that we are writing on needs to have these numbers

bool fileLoadWrite(string filename) //The created function named fileLoadWrite with one string perameter
{
    ofstream file; //The syntax for writing to a file
    file.open(filename); //Opening the file in the perameter
    int num = 1; //A declared variable named num starting at 1
    int finalnum = 0; //A declared variable named finalnum starting at 0
    
    if (file.fail()) //If the file fails to open
    {
        cout << "Opening file failed." << endl; //Display the content "Opening file failed." to the user
    }
    
    else if (file.is_open()) //If the file does open
    {
        for (int i = 0; i < 10; i++) //A while loop to gather the numbers being squared
        {
            finalnum = num * num; //An equation to get the number squared
            file << finalnum << endl; //Displaying the final number that is being squared
            num++; //The number that is being squared will increase by 1
        }
        return 0; //Return 0
    }
}

int main() //Int main
{
    cout << fileLoadWrite("myFile.txt") << endl; //Test case
}