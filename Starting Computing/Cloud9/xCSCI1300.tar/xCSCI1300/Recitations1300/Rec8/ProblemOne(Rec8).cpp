// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 8 - Problem 1

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
using namespace std;

//Create a function named checkFile
    //This function needs only one perameter
        //(1) A string perameter for the filename

    //If there is a file that you are looking for in the directory
        //Return true
    //If there is not a file that you are looking for in the directory
        //Return false

bool checkFile (string filename) //The created function named checkFile with one string perameter
{
    ifstream file; //A syntax for reading a file
    file.open(filename); //Opening the file in the perameter
    
    if (file.is_open()) //If the file opens
    {
        return true; //Return true
    }
    
    else if (file.fail()) //If the file does not open
    {
        return false; //Return false
    }
}

int main() //Int main
{
    cout << checkFile("myFile.txt") << endl; //Test case
}