// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 5 - Problem 4

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

//Create a function named getLastIndex
    //Function needs to have two perameters
        //One perameter needs to be a character perameter (Ex. 'A', 'x')
        //The Second perameter needs to be a string perameter (Ex. "Wassup", "Yuh")
        
//If the normal string is empty
    //Return -1
//If there is not a character you are looking for in the normal string
    //Return -2
//If there is a character you are looking for in the normal string
    //The index of the normal string is now the number of the count
//At the end, return the index at which the character you were looking for was reached

int getLastIndex(char chars, string normstr) //Fucntion named getLastIndex with character perameter & string perameter
{
    int count = -1; //Integer indicator for the number of time you've seen the character in the string
    //i = 0;
    
    if (normstr.length() == 0) //If the string is empty
    {
        return -1; //Return -1
    }
    
    for (int i = 0; i < normstr.length(); i++) //A For loop that looks through the whole string
    {
        if (normstr[i] == chars) //If the index of the normal string is the character of the string you're looking for
        {
            count = i; //The count is now the index at which you came across the character you were looking for
        }
    }
    
    if (count == -1) //If the character you were looking for was not found in the normal string
    {
        return -2; //Return -2
    }
    
    return count; //At the end, return the index at which the character you were looking for was reached
}

int main() //Int Main
{
    cout << getLastIndex('M', "Marti") << endl; //Test Case 1
    cout << getLastIndex('o', "Cookin") << endl; //Test Case 2
    cout << getLastIndex('e', "Houdini") << endl; //Test Case 3
}