// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 5 - Problem 1

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

//Make a function named getWordCount
    //Function needs a string perameter
    //Function needs to return the amount of words in the string perameter
    //Function will not print anything

//If there is nothing in the string
    //The number of spaces will be 0
//Go through each storage spot in the string
    //If there is a space in the string
        //Increase the number of words there are
        //Increase the number of spaces there are

int getWordCount(string str) //Integer Function named getWordCount (One String Perameter)
{
    int words = 1; //Integer indicator for the words
    int counter = 0; //Integer indicator for the counter so the while loop doesn't execute forever
    int spaces = 0; //Integer indicator for the spaces in the string
    
    if (str[0] == '\0') //If there is nothing in the string
        {
            return spaces; //Return the number of spaces in the string
        }
    
    while (counter < str.length()) //While the counter is less than the length of the string (Reading the string)
    {
        if (str[counter] == ' ') //Going through each storage spot in the string to see if there is a space
        {
            words++; //Words will increase by 1
            spaces++; //Spaces will increase by 1
        }
        counter++; //The counter needs to increase for the while loop to eventually end
    }
    
    if (counter = str.length()) //If the counter equals the length of the string
    {
        return words; //Return the amount of words in the string
    }
    
}

int main() //Int Main
{
    cout << getWordCount("ads sad fd fa") << endl; //Test case 1
    cout << getWordCount("") << endl; //Test case 2
    cout << getWordCount("Houdini") << endl; //Test case 3
}