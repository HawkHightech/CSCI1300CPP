// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 5 - Problem 3

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

//There needs to be a function named getMatchCount
    //Function needs to have two string perameters
        //First string perameter is a substring (Part of the whole string)
        //Second string perameter is the normal string (The whole string)

//If the substring is empty or the normal string is empty
    //Return -1
//If the length of the substring is longer than the length of the normal string
    //Return -2
    
//While you're looking through the whole normal string
    //If there is a substring in the normal string
        //The count will increase to indicate that there was a substring in the normal string
    //At the end of the finding the number of substrings in the normal string
        //Return how many substrings were in the normal string

int getMatchCount(string lilstr, string normstr) //Function named getMatchCount with two 
{
    //int counter = 0;
    int count = 0; //Integer indicator that represents the count starting at 0
    
    if (lilstr.length() == 0 || normstr.length() == 0) //If the substring or normal string is empty
    {
        return -1; //Return -1
    }
    
    if (lilstr.length() > normstr.length()) //If the substring is longer than the normal string
    {
        return -2; //Return -2
    }
    
    for (int i = 0; i < normstr.length(); i++) //A For loop that looks through the whole normal string
    {
        if (normstr.substr(i,lilstr.length()) == lilstr) //If the index of the normal string of the substring equals the substring
        {
            count++; //The count will increase (Indicates that there was a substring in the normal string)
        }
    }
    
    return count; //Returns the number of substrings in the normal string
}

int main() //Int Main
{
    cout << getMatchCount("MI", "MISSISSIPPI") << endl; //Test Case 1
    cout << getMatchCount("Yo", "YoYoYo") << endl; //Test Case 2
    cout << getMatchCount("Hawkins", "Alexander") << endl; //Test Case 3
}