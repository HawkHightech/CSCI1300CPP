// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 5 - Problem 2

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

//Create a function called getDigitCount
    //Function needs to have a string perameter
    //Function needs to look at every index in the string & see if there is a number in the string
    //Function will not print anything
    
//There needs to be a while loop to look through the whole string
    //If there is a number between 0 & 9 in the string
        //There will be a count that will increase that indicates there was a number in the string

int getDigitCount(string str) //Function named getDigitCount that takes in a string perameter
{
    int counter = 0; //Integer indicator so the while loops doesn't execute forever
    int count = 0; //Integer indicator for the amount of numbers in the string
    int i = 0; //Integer indicator for the index of the string
    
    while (counter < str.length()) //A while loop to look through the whole string
    {
        if (str[i] == '0' or str[i] == '1' or str[i] == '2' or str[i] == '3' or str[i] == '4' or str[i] == '5' or str[i] == '6' or str[i] == '7' or str[i] == '8' or str[i] == '9')
        // ^ If there is a number between 0 & 9 in the string
        {
           count++; //The count will increase by 1
        }
        i++; //i needs to increase by 1 to look at each index of the string
        counter++; //counter needs to increase so the while loop doesn't always execute
    }
    return count; //Return the amount of numbers in the string
}

int main() //Int Main
{
    cout << getDigitCount("ehak12kjhdbsak23211dfshjvb") << endl; //Test case 1
    cout << getDigitCount("") << endl; //Test case 2
    cout << getDigitCount("gvng257a$vpmob13") << endl; //Test case 3
}