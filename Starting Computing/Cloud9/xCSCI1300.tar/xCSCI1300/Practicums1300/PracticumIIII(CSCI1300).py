#Question 1
def check_palindrome_case_insensitive(string):
    str = string.lower()
    for i in range(len(str)//2):
        if str[i] != str[len(str)-i-1]:
            return False
    return True

#Question 2  
def check_palindrome(string):
    for i in range(len(string)//2):
        if string[i] != string[len(string)-i-1]:
            return False
    return True


#Question 3
def hailStoneTracker(initial_altitude):
    temp = initial_altitude
    l = []
    an = temp
    while temp != 1:
        l.append(temp)
        if temp%2 == 0:
            temp = temp/2
        else:
            temp = 3*temp+1
        an = max(an, temp)
    l.append(temp)
    print("Max:", an)
    return l
    
#Question 4
def CountItems(items, value):
    count = 0
    for i in items:
        if i > value:
            count = count + 1 
    return count
    
#Question 5
def CountItems(items, letter):
    count = 0
    for i in items:
        if i[-1] == letter:
            count = count + 1
    return count

#Question 6
def find_host_in_file(file_name, hostname):
    name = []
    try:
        file = open(file_name, 'r')
        for line in file:
            address = line.strip().split("@")
            if len(address) > 1 and address[1] == hostname:
                name.append(address[0])
        return name
    except:
        return -1
        
#Question 7       
def create_dictionary(values):
    dictionary = {}
    for key in values:
        if key[0] in dictionary:
            dictionary[key[0]].append(key)
        else:
            dictionary[key[0]] = [key]
    #print(dictionary)
    return dictionary 
    
#Question 8
def repList(List, n):
    new_list = []
    for i in List:
        new_list += [i] * n
    return new_list     
    
#Question 9    
def find_items_in_file(file_name, number):
    try:
        List = []
        infile = open(file_name, 'r')
        for line in infile:
            line = line.strip()
            line = line.split('|')
            if int(line[1]) == number:
                List.append(line[0].strip())
        return List    

    except:
        return -1
        
