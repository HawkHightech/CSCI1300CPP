#1

class ChildGrowth
{
    public:
        ChildGrowth();
        ChildGrowth(string n);
        ChildGrowth(string n, int a);
        ChildGrowth(string n, int a, float h[], float w[]);
        string getName();
        void setName(string n);
        int getCurrentAge();
        void setCurrentAge(int a);
        void setHeight(float h[]);
        void setWeight(float w[]);
        float feetToMeter(float feet);
        float poundToKg(float pound);
        float calculateBmi(int age);
        string getCategory(int age);

    private:
        int currentAge;
        string category;
        string name;
        float height[10];
        float weight[10];
        float weightMetricConversion;
};


#2

class Quarterback
{
    public:
        Quarterback();
        void setName(string new_name);
        string getName();
        void setComp(int x);
        void setAtt(int x);
        void setYards(int x);
        void setTD(int x);
        void setPick(int x);
        int getPick();
        int getComp();
        int getAtt();
        int getYards();
        int getTD();
        void PassCompleted(int x);
        void PassAttempted();
        void Interception();
        Quarterback(string d);
        float PasserRating();
        void Touchdown(int x);

    private:
        int pass_attempts;
        int pass_completes;
        int total_yards;
        int touchdowns;
        int intercepts;

        string name;
};


#3

class Book
{
    public:
        Book();
        Book(string t, int u, float s);
        
        string getTitle();
        int getUnits();
        float getSales();
        
        void setTitle(string ti);
        void setUnits(int un);
        void setSales(float sa);
        
        float AvgCost()
        {
            float average;
    
            average = sales / units;
            return average;
        }
        
    private:
        string title;
        int units;
        float sales;
        
};

Book::Book()
{
    title = "";
    units = 0;
    sales = 0.0;
}

Book::Book(string t, int u, float s)
{
    title = t;
    units = u;
    sales = s;
}

string Book::getTitle()
{
    return title;
}

int Book::getUnits()
{
    return units;
}

float Book::getSales()
{
    return sales;
}

void Book::setTitle(string ti)
{
    title = ti;
}

void Book::setUnits(int un)
{
    units = un;
}

void Book::setSales(float sa)
{
    sales = sa;
}


#4

class CoffeeCustomer
{
    private:
        string customerName;
        string brewType;
        int numCups = 0;
    
    public:
        CoffeeCustomer()
        {
            customerName = "";
            brewType = "";
            numCups = 0;
        }
        
        CoffeeCustomer(string cu, string br)
        {
            customerName = cu;
            brewType = br;
        }
        
        void setCustomerName(string na)
        {
            customerName = na;
        }
        
        string getCustomerName()
        {
            return customerName;
        }
        
        int setBrewType(string br)
        {
            if(br == "aeropress" || br == "cold brew" || br == "drip")
                {
                    brewType = br;
                    return 1;
                }
            else
                {
                    return 0;
                }
        }
        
        string getBrewType()
        {
            return brewType;
        }
        
        int setNumCups(int c)
        {
            if(c < 0)
                {
                    return -1;
                    numCups = c;
                }
                
            else if (c > 0)
                {
                    numCups = c;
                    return 1;

                }
        }
        
        int getNumCups()
        {
            return numCups;
        }
};

#5

class TextBook
{
    public:
    TextBook()
    {
        title = "";
        pages = 0;
        cost = 0.0;
        online = false;
    }
    
    TextBook(string t, int p, float c, bool o)
    {
        title = t;
        pages = p;
        cost = c;
        online = o;
    }
    
    string getTitle()
    {
        return title;
    }
    
    int getPages()
    {
        return pages;
    }
    
    float getCost()
    {
        return cost;
    }
    
    bool getOnline()
    {
        return online;
    }
    
    void setTitle(string t)
    {
       title = t;
    }
    
    void setPages(int p)
    {
        pages = p;
    }
    
    void setCost(float c)
    {
        cost = c;
    }
    
    void setOnline(bool o)
    {
        online = o;
    }
    
    float CostPerPage()
    {
        float avgcost = 0.0;
        
        avgcost = cost / pages;
        return avgcost;
    }
    
    private:
    string title;
    int pages;
    float cost;
    bool online;
    
};

#6

class Country
{
    public:
        Country()
        {
            for (int i = 0; i < 50; i++)
            {
                area[i] = -1;
                stateName[i] = "";
            }
            
        }
        
        void ReadFile(string filename)
        {
            string line;
            ifstream file;
            int i = 0;
            
            file.open(filename);
            
            if (!file.is_open())
            {
                //cout << "file cannot be open" << endl;
            }
            
            else
            {
                while(getline(file,line))
                {
                    string words[2];
                    split(line, ',', words, 2);
                    
                    if (words[0][0] >= '0' && words[0][0] <= '9')
                    {
                        area[i] = stoi(words[0]);
                        stateName[i] = words[1];
                    }
                    
                    else
                    {
                        stateName[i] = words[0];
                        area[i] = stoi(words[1]);
                    }
                    
                    i++;
                }
            }
        }
        
        string getMaxAreaState()
        {
            float max = 0.0;
            string maxs = "";
            
            for(int i = 0; i < 50; i++)
            {
                if(area[i] > max)
                {
                    max = area[i];
                    maxs = stateName[i];
                }
            }
            
            return maxs;
        }
    
    private:
        string stateName[50];
        int area[50];
};

#7

class Players
{
    public:
        Players()
        {
            for(int i = 0; i < 50; i++)
            {
                names[i] = "";
                salaries[i] = -1;
            }
        }

        void ReadFile(string f)
        {
            ifstream file(f);
            string line;

            if(file.is_open())
            {
                int i = 0;

                while(getline(file, line))
                {
                    string temp[2];
                    split(line, ',', temp, 50);
                    
                    names[i] = temp[0];
                    salaries[i] = stof(temp[1]);
                    
                    i++;
                    
                }
                
                return;
                
            }
            
            else
            {
                return;
            }
            
        }

        float MaxSalary()
        {
            float max = 0.0;

            for(int i = 0; i < 50; i++)
            {
                if(salaries[i] > max)
                {
                    max = salaries[i];
                }
            }

            return max;

        }

        string MaxSalaryName()
        {
            string n = "";
            float max = 0.0;


            for(int i = 0; i < 50; i++)
            {
                if(salaries[i] > max)
                {
                    max = salaries[i];
                    n = names[i];
                }
            }

            return n;
            
        }

    private:
        float salaries[50];
        string names[50];
};

#8

class Drawing
{
    public:
        Drawing()
        {
            year = 1800;
            title = "";
            artist = "";
        }
        
        Drawing(int y, string t, string a)
        {
            year = y;
            title = t;
            artist = a;
        }
        
    private:
        int year;
        string title;
        string artist;
};

#9

class Mural
{
    public:
        Mural()
        {
            building = "";
            year = 0;
            artist = "";
        }
        
        Mural(string b, int y, string a)
        {
            building = b;
            year = y;
            artist = a;
        }
        
    
    private:
        string building;
        int year;
        string artist;
};

#10

class Painting
{
    public:
        Painting()
        {
            value = 0.0;
            title = "";
            artist = "";
        }
        
        Painting(float v, string t, string a)
        {
            value = v;
            title = t;
            artist = a;
        }
    
    
    private:
        float value;
        string title;
        string artist;
};

#11

class Sculpture
{
    public:
        Sculpture()
        {
            title = "";
            value = 0.0;
            artist = "";
        }
        
        Sculpture(string t, float v, string a)
        {
            title = t;
            value = v;
            artist = a;
        }
    
    private:
        string title;
        float value;
        string artist;
};

#12

class Star
{
    public:
        int numPlanets; // number of values currently used in array
        
        Star()
        {
            numPlanets = 0;

            for(int i = 0; i < 10; i++)
            {
                radii[i] = -1.0;
            }
        }

        float CalcAverage()
        {
            float c;

            for(int i = 0; i < numPlanets; i++)
            {
                c += radii[i];
            }


            c /= numPlanets;

            return c;
        }

        float radii[10];
};