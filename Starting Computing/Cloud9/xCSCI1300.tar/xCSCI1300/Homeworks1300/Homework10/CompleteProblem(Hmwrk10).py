# Author: Alexander P. Hawkins CS1300 Spring 2018
# Recitation: 104 Yichen Wang
# Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
# Homework 10

class library:
    def __init__(self): # define function 
        self.book_list = [] 
        self.user_list = {}  
        pass 
    
    
    def read_book(self, file_name): # defining the rate book fucntion 
        with open(file_name, "r") as f: # file open 
            for line in f:  
                self.book_list.append(line.strip().lower().split(",")) # splits the file and lowers
    
    def read_rating(self, file_name): #defining the funciton read ratings
        with open(file_name, "r") as f: #reads the file
            for line in f:
                user_name, ratings = line.strip().split(",") # splits the file by ,
                
               
                int_ratings = [] 
                for r in ratings.split(): #splits the ratings by space
                    int_ratings.append(int(r)) 
                    
                # put it into the dictioanry 
                self.user_list[user_name] = int_ratings
                
    def log_in(self): 
        print("Data Loaded successfully!") 
        name = input("Welcome to the Library, What is your name?:\n") 
        name = name.lower()
        while len(name) == 0:#edge case
            print("You provided an empty username, Please provide a valid user name to login or register")
            name = input("Enter your name again:\n")
            
        if name in self.user_list: # checks returning user
            print("Welcome back,", name)
        else: # if new
            print("Welcome to the Library,", name) 
            self.user_list[name] = [0] * len(self.book_list)#adds new user
        
        return name 
    
    def viewRatings(self, user_name):#allows users to view thier ratings
        bookRated = False 
        for j in range(len(self.book_list)):
            if self.user_list[user_name][j] != 0:
                if bookRated == False: 
                    print("Here are the books that you have rated:")
                print("Title :", self.book_list[j][1])
                print("Rating :", self.user_list[user_name][j])
                print("------------------------------")
                bookRated = True
            
        if bookRated == False:
            print("You have not rated any books as yet:")
        
    def rate_book(self, current_user_name):#gets rating of the books and allows you to enter your own rating
        found_book = False
        while found_book == False:
            book_name = input("Enter the name of the book that you would like to rate:\n")
            rating = input("Enter your rating of the book:\n")
            book_name = book_name.lower()
            for i in range(len(self.book_list)):
                if book_name == self.book_list[i][1]: 
                    self.user_list[current_user_name][i] = int(rating)
                    found_book = True
                    print("Success!")
                    print("Thank-you. The rating for the book titled \""+book_name+"\" has been updated to", rating)
            
            if found_book == False:
                print("The book you requested does not exist in the database")
                    


    def ssd(self, ratingA, ratingB):
        return sum([(a-b)**2 for a, b in zip(ratingA, ratingB)])
    
    def get_most_sim_user(self, user_name):#gets most similar user 
        ssd_min = 100000 
        sim_user = None 
        
        for user in self.user_list:
            if user != user_name:
                ssd_score = self.ssd(self.user_list[user_name], self.user_list[user])
                
                if ssd_score < ssd_min:
                    ssd_min = ssd_score
                    sim_user = user
        return sim_user 
        
        
    def getRecommendation(self, current_user_name):#uses most similar user score to get book recommendations
        most_sim_user = self.get_most_sim_user(current_user_name)
        sim_user_rating = self.user_list[most_sim_user]
        
        count = 0
        for i in range(len(self.book_list)):
            if count < 10:
                if self.user_list[current_user_name][i] == 0:
                    if sim_user_rating[i] >= 3:
                        if count == 0:
                            print("Here are some of the books that we think you would like")
                        
                        print("{} by {}".format(self.book_list[i][1], self.book_list[i][0]))
                        count += 1
                    
        if count == 0:
            print("There are no recommendations for you at present")
                
    def menu(self):#the menu that allows the user to navigate the program
        user_name = self.log_in()
        while True:
            answer=input("Would you like to (v)iew your ratings, (r)ate a book, (g)et recommendations, or (q)uit?:\n")
            if answer == "v":
                self.viewRatings(user_name)
            elif answer == "r":
                self.rate_book(user_name)
            elif answer == "g":
                self.getRecommendation(user_name)
            elif answer == "q":
                print("Goodbye!")
                break
            else:
                print("Please input a valid choice")

l = library()
l.read_book("books.txt")
l.read_rating("ratings.txt")
l.menu()
