// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 4 - Problem 3

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

int main() //Int Main
{
    //cout << findSimilarityScore("ACCT", "ACCG") << endl; //Test Case 1
    //cout << findSimilarityScore("ATTTTGADAG", "ATATTTADAA") << endl; //Test Case 2
    //cout << findSimilarityScore("", "") << endl; //Test Case 3
    
    //cout << findBestMatch("ATABADCSAS", "ACT") << endl; //Test Case 1
    //cout << findBestMatch("", "ACT") << endl; //Test Case 2
    //cout << findBestMatch("GCCA", "GCCA") << endl; //Test Case 3
    
    cout << "Please enter genome 1: " << endl; //Displaying the user to input Genome 1
    cin >> genomeOne; //Storing the User's Input into the computer
    
    cout << "Please enter genome 2: " << endl; //Displaying the user to input Genome 2
    cin >> genomeTwo; //Storing the User's Input into the computer
    
    cout << "Please enter genome 3: " << endl; //Displaying the user to input Genome 3
    cin >> genomeThree; //Storing the User's Input into the computer
    
    cout << "Please enter a sequence: " << endl; //Displaying the user to input a sequence
    cin >> first_sequence; //Storing the User's Input into the computer
    
    if (genomeOne.length() == 0 || genomeTwo.length() == 0 || genomeThree.length() == 0 || first_sequence.length() == 0) //If any of the user's input is empty
    {
        cout << "Genome and sequence cannot be empty." << endl; //Display to the user that the genome and sequence cannot be empty
        return 0; //Return 0
    }
    
    while (first_sequence.length() > genomeOne.length() || first_sequence.length() > genomeTwo.length() || first_sequence.length() > genomeThree.length()) //If the sequence is longer than any genome
    {
        cout << "Sequence cannot be longer than genomes." << endl; //Display to the user that the sequence cannot be longer
        cout << "Please enter a sequence: " << endl; //Ask the user to insert another sequence for the genomes
        cin >> first_sequence; //The user's sequence is inserted into the system
    }
    
    //if (first_sequence.length() < genomeOne.length() || first_sequence.length() < genomeTwo.length() || first_sequence.length() < genomeThree.length())
    //{
        //return 0;
    float Highscore_One = findBestMatch(genomeOne, first_sequence); //Declaring a best match for the first genome
    float Highscore_Two = findBestMatch(genomeTwo, first_sequence); //Declaring a best match for the second genome
    float Highscore_Three = findBestMatch(genomeThree, first_sequence); //Declaring a best match for the third genome
        
    //}
    
    if (Highscore_One > Highscore_Two && Highscore_One > Highscore_Three) //If Genome One is the best match
    {
        cout << "Genome 1 is the best match." << endl; //Display to the user that Genome One is the best match
    }
    
    if (Highscore_Two > Highscore_One && Highscore_Two > Highscore_Three) //If Genome Two is the best match
    {
        cout << "Genome 2 is the best match." << endl; //Display to the user that Genome Two is the best match
    }
    
    if (Highscore_Three > Highscore_Two && Highscore_Three > Highscore_One) //If Genome Three is the best match
    {
        cout << "Genome 3 is the best match." << endl; //Display to the user that Genome Three is the best match
    }
    
    if (Highscore_One == Highscore_Two && Highscore_One > Highscore_Three) //If Genomes One & Two are the best matches
    {
        cout << "Genome 1 is the best match." << endl; //Display to the user that Genome One is the best match
        cout << "Genome 2 is the best match." << endl; //Display to the user that Genome Two is the best match
    }
    
    if (Highscore_Three == Highscore_Two && Highscore_Three > Highscore_One) //If Genomes Two & Three are the best matches
    {
        cout << "Genome 2 is the best match." << endl; //Display to the user that Genome Two is the best match
        cout << "Genome 3 is the best match." << endl; //Display to the user that Genome Three is the best match
    }
    
    if (Highscore_Three == Highscore_One && Highscore_Three > Highscore_Two) //If Genomes One & Three are the best matches
    {
        cout << "Genome 1 is the best match." << endl; //Display to the user that Genome One is the best match
        cout << "Genome 3 is the best match." << endl; //Display to the user that Genome Three is the best match
    }
    
    if (Highscore_Three == Highscore_Two && Highscore_Two == Highscore_One) //If Genomes One, Two, & Three are the best matches
    {
        cout << "Genome 1 is the best match." << endl; //Display to the user that Genome One is the best match
        cout << "Genome 2 is the best match." << endl; //Display to the user that Genome Two is the best match
        cout << "Genome 3 is the best match." << endl; //Display to the user that Genome Three is the best match
    }
    

}