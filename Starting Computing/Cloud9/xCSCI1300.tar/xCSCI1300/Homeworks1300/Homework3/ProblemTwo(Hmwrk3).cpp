// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 3 - Problem 2

#include <iostream>
#include <math.h>
using namespace std;

//Create a function named Wind Chill Calculator
    //There needs to be two floating point perameters
        //The first perameter needs to be the Air Temperature (T)
        //The Second peramter needs to be the Wind Speed (V)
        //Note : In that order

//The power of V does not change. The value will always be 0.16
//If the Air Temperature is greater than or equal to 0 & the Wind Speed is also greater than or equal to 0
    //Use the given calculation
        //Note:Do not forget to use the power function
        //Return the value of the Given calculation
//If either the Air Temperature or the Wind Speed is less than 0
    //Display "Not applicable" to the user
    //Return 0

float windChillCalculator (float T,float V) //The function named windchillCalculator with two floating point perameters
    {
        double b; //The Declared double value for the power of V
        float wind_chill; //The final calculation of the given equation (Declared)
        b = 0.16; //The value of the power of V (0.16)
        
        if (V >= 0) //If the Air Temperature is greater than or equal to 0 & the Wind Speed is also greater than or equal to 0 
        {
            wind_chill = 35.74 + (0.6215 * T) - (35.75 * pow(V,b)) + (0.4275 * T) * (pow(V,b)); //The Given Equation
            cout << wind_chill << " F" << endl; //The final calculation of the given equation
            // return wind_chill; //Return 0
        }
        else //If either the Air Temperature or the Wind Speed is less than 0
        {
            cout << "Not applicable" << endl; //Display "Not applicable" to the user
            return 0; //Return 0
        }
    }
void printWindChill(float T, float low_wind_speed, float high_wind_speed, float wind_speed_step)
    {

        float V;
        float wind_chill;
        
        while (low_wind_speed <= high_wind_speed)
        {
            if (low_wind_speed > high_wind_speed || wind_speed_step < 0)
        {
            cout << "Invalid input" << endl;
        }
            else
            {
                V = low_wind_speed + wind_speed_step;
                cout << "The wind chill is " << wind_chill << " degrees F for an air Temperature of " << T;
                cout << " degrees F and a wind speed of " << V << " mph." << endl;
                low_wind_speed++;
            }
        }
        
    }

int main()
{
    windChillCalculator(30.0,5.2); //Test Case 1
    windChillCalculator(-30.0,5.0); //Test Case 2
    windChillCalculator(30.0,-5.0); //Test Case 3
    
    printWindChill(30.0, 5.0, 8.0, 1.0);
}