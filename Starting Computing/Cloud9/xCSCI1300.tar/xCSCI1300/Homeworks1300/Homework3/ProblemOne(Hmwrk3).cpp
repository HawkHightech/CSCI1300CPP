// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 3 - Problem 1

#include <iostream>
#include <string>
using namespace std;

//Make Three functions called Story1, Story2, & Story3.
    //None of these functions should have perameters.
//Any function cannot have the return output.

//Story1 will ask for a plural noun, an occupation, an animal name, & a place (NOT perameters).
    //When these user inputs are in the system, they will be stored into the system and the story will be displayed.
//Story2 will ask for your name & a state/country.
    //When these user inputs are in the system, they will be stored into the system and the story will be displayed.
//Story3 will ask for your first name, a relative, and a verb.
    //When these user inputs are in the system, they will be stored into the system and the story will be displayed.


//Ask the user which game he wants to play.
    //If the user inputs the number 1, then Story1 will begin
    //If the user inputs the number 2, then Story2 will begin
    //If the user inputs the number 3, then Story3 will begin
    //If the user inputs the letter q, then the game will reply "Good bye" & the game will end.
    //If the user inputs ANYthing else other than what is above, the game will replay "Valid choice not selected" & Ask again.


void story1()
{
    string plural_noun; //Delcaring a string called Plural Noun (Needs to be a string)
    string occupation; //Delcaring a string called Occupation (Needs to be a string)
    string animal_name; //Delcaring a string called Animal name (Needs to be a string)
    string place; //Delcaring a string called Place (Needs to be a string)
    
    cout << "Enter a plural noun: " << endl; //Displays what I want the user to input
    cin >> plural_noun; //The user's input is gathered into the system's storage
    //getline(cin, plural_noun);
    
    cout << "Enter an occupation: " << endl; //Displays what I want the user to input
    cin >> occupation; //The user's input is gathered into the system's storage
    // getline(cin, occupation);
    
    cout << "Enter an animal name: " << endl; //Displays what I want the user to input
    cin >> animal_name; //The user's input is gathered into the system's storage
    //getline(cin, animal_name);
    
    cout << "Enter a place: " << endl; //Displays what I want the user to input
    cin >> place; //The user's input is gathered into the system's storage
    //getline(cin, place);
    
    cout << "In the book War of the " << plural_noun << ", the main character is an anonymous " << occupation;
    cout << " who records the arrival of the " << animal_name << "s in " << place << "." << endl;
    // ^ The Ending Story
}

void story2()
{
    string name; //Delcaring a string called Name (Needs to be a string)
    string state_country; //Delcaring a string called State or Country (Needs to be a string)
    
    cout << "Enter a name: " << endl; //Displays what I want the user to input
    cin >> name; //The user's input is gathered into the system's storage
    //getline(cin, name);
    
    cout << "Enter a state/country: " << endl; //Displays what I want the user to input
    cin >> state_country; //The user's input is gathered into the system's storage
    //getline(cin,state_country);
    
    cout << name << ", I've got a feeling we're not in " << state_country << " anymore." << endl; //The Ending Story
    
}

void story3()
{
    string first_name; //Delcaring a string called First Name (Needs to be a string)
    string relative; //Delcaring a string called Relative (Needs to be a string)
    string verb; //Delcaring a string called Verb (Needs to be a string)
    
    cout << "Enter a first name: " << endl; //Displays what I want the user to input
    cin >> first_name; //The user's input is gathered into the system's storage
    // getline(cin, first_name);
    
    cout << "Enter a relative: " << endl; //Displays what I want the user to input
    cin >> relative; //The user's input is gathered into the system's storage
    // getline(cin, relative);
    
    cout << "Enter a verb: " << endl; //Displays what I want the user to input
    cin >> verb; //The user's input is gathered into the system's storage
    // getline(cin, verb);
    
    cout << "Hello. My name is " << first_name << ". You killed my " << relative << ". Prepare to " << verb << "." << endl;
    // ^ The ending story
    
}

void menu()
{
    string answer; //Delcaring a string called Answer (Needs to be a string)

    cout << "Which story would you like to play? Enter the number of the story (1, 2, or 3) or type q to quit:" << endl; //Displays hat I want the user to input
    cin >> answer; //The user's input is gathered into the system's storage
    
    
    if (answer == "1") //If the user's answer from the last question is a 1.
    {
        story1(); //Story 1 Begins ^.^
        menu();
    }
    
    else if (answer == "2") //If the user's answer from the last question is a 2.
    {
        story2(); //Story 2 Begins ^.^
        menu();
    }
    
    else if (answer == "3") //If the user's answer from the last question is a 3.
    {
        story3(); //Story 3 Begins ^.^
        menu();
    }
    
    else if (answer == "q") //If the user's answer from the last question is a q (for quit).
    {
        cout << "good bye" << endl; //The Game Ends :(
    }
    
    else //If there is ANY other input different from what I'm asking, try again.
    {
        cout << "Valid choice not selected." << endl; //Displays the reason why it didn't work.
        menu(); //Try again (Back to beginning).
    }
}

int main()
{
    // string name;
    // string occupation;
    // string place;

    // cout << "Enter your name: " << endl;
    // getline(cin, name);
    
    // cout << "Enter an occupation: " << endl;
    // getline(cin, occupation);
    
    // cout << "Enter a place: " << endl;
    // getline(cin, place);
    
    // cout << name << " is a " << occupation << " who lives in " << place << "." << endl;
    
    //----------------------------------------------------------------------------------------------
    
    // story1();
    // story2();
    // story3();
    menu(); //The Function called Menu begins.
    
}