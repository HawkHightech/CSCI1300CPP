# Author: Alexander P. Hawkins CS1300 Spring 2018
# Recitation: 104 Yichen Wang
# Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
# Homework 9 - Problem 2

#Compute grade takes in a perameter for a file name
#Read each line of the file
#Add all the values up & divide by however many there are
#Return the overall grade

def compute_grade(file_name):
     overall_grade = 0
     total_weight = 0
     try:
          with open(file_name) as f:
               for line in f:
                    line_list = line.split(',')
                    grade = 0
                    for i in range(0, len(line_list) - 2):
                         grade = grade + int(line_list[i])
                    grade = float(grade/(len(line_list) - 2))
                    grade = grade * float(line_list[-1])
                    total_weight = total_weight + float(line_list[-1])
                    overall_grade = overall_grade + grade
               overall_grade = overall_grade / total_weight
     except:
          return "File not found"
     return overall_grade