# Author: Alexander P. Hawkins CS1300 Spring 2018
# Recitation: 104 Yichen Wang
# Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
# Homework 9 - Problem 5

#Provide a menu to the user
    #Add words to the dictionary
    #De-slang a sentence
    #quit
#User will add a word until they quit
#When they quit it will show the amount of entries in the dictionaries


def update_dictionary(filename, dictionary):
    try:
        with open(filename) as my_file:
            print(filename, "loaded successfully.")
            for line in my_file:
                phrases = line.strip().split(",")
                dictionary[phrases[0]] = phrases[1]
        print('The dictionary has ' + str(len(dictionary.items()))+' entries.')
    except:
        print(filename, 'does not exist.\nThe dictionary has 0 entries.')
    return dictionary
    
def deslang(slang, dictionary):
    arr = []
    arr = slang.split()
    for i in range(len(arr)):
        fullarr = arr[i]
        if fullarr in dictionary:
            slang = slang.replace(fullarr, dictionary[fullarr])
    return slang
    
def main():
    menuChoice = ""
    dictionary1 = {}
    while menuChoice != "q":
        menuChoice = input("Would you like to (a)dd words to the dictionary, (d)e-slang a sentence, or (q)uit?: ")
        if menuChoice == "a":
            my_file = ""
            while len(my_file) == 0: 
                my_file = input("Enter a filename: ")
            dic = update_dictionary(my_file, dictionary1) #calls the update dictionary function with given parameter
        elif menuChoice == "d":
            deslangEmpty = ""
            while len(deslangEmpty) == 0: #emtpy string 
                deslangEmpty = input("Enter a sentence: ")
            print(deslang(deslangEmpty, dictionary1)) #prints the deslanges word with calling the deslang function with given parameters

if __name__ == "__main__": #if namem is main
    main() #main