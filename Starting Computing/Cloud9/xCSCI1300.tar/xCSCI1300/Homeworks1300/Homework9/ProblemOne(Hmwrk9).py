# Author: Alexander P. Hawkins CS1300 Spring 2018
# Recitation: 104 Yichen Wang
# Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
# Homework 9 - Problem 1

#Go through each name in the list
#THe first name will be the key
#The last name will be the value of list
#For every same first name in the list, there will be a value of list for that name
#Return the list

def countNames(list):
    a={}
    for name in list:
        firstlast=name.split()
        if len(firstlast)>0:
            first=firstlast[0].strip()
            last=firstlast[1].strip()
            if first in a:
                a[first].append(last)
            else:
                last1=[last]
                a[first]=last1
    return a