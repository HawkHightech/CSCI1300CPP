# Author: Alexander P. Hawkins CS1300 Spring 2018
# Recitation: 104 Yichen Wang
# Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
# Homework 9 - Problem 4

#Deslang takes in two perameters
    #A string
    #A dictionay
#Each letter that is in the input equals a word in the dictionary
#Translate the letter into the actual word
#Return the new sentence

def update_dictionary(filename, dictionary):
    try:
        with open(filename) as my_file:
            print(filename, "loaded successfully.")
            for line in my_file:
                phrases = line.strip().split(",")
                dictionary[phrases[0]] = phrases[1]
        print('The dictionary has ' + str(len(dictionary.items()))+' entries.')
    except:
        print(filename, 'does not exist.\nThe dictionary has 0 entries.')
    return dictionary
    
def deslang(slang, dictionary):
    arr = []
    arr = slang.split()
    for i in range(len(arr)):
        fullarr = arr[i]
        if fullarr in dictionary:
            slang = slang.replace(fullarr, dictionary[fullarr])
    return slang