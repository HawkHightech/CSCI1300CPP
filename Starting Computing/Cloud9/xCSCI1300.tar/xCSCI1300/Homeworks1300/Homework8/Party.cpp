// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 8 - Oregon Trail

#include <iostream>
#include "Party.h"
#include <random>

using namespace std;

Party::Party()
{

}

Party::~Party()
{
    //Deconstructor
}

double Party::getFoodp()
{
    return foodp;
}

void Party::setFoodp(double yums)
{
    foodp = yums;
}
int Party::getqFood()
{
    return qFood;
}

void Party::buyFood(int q)
{
    qFood = q;
}

double Party::getMoney()
{
    return money;
}

void Party::setMoney(double guap)
{
    money = guap;
}


double Party::getAmmop()
{
    return ammop;
}

void Party::setAmmop(double guns)
{
    ammop = guns;
}

int Party::getAmmoq()
{
    return ammoq;
}

void Party::setAmmoq(int q)
{
    ammoq = q;
}

double Party::getOxenp()
{
    return yokep;
}

void Party::setOxenp(double oxen)
{
    yokep = oxen;
}

int Party::getOxenq()
{
    return yokeq;
}

void Party::setOxenq(int q)
{
    yokeq = q;
}

double Party::getPartsp()
{
    return partsp;
}

void Party::setPartsp(double spares)
{
    partsp = spares;
}

int Party::getPartsq()
{
    return partsq;
}

void Party::setPartsq(int q)
{
    partsq = q;
}

double Party::getMedicalp()
{
    return medicalp;
}

void Party::setMedicalp(double meds)
{
    medicalp = meds;
}

int Party::getMedicalq()
{
    return medicalq;
}

void Party::setMedicalq(int q)
{
    medicalq = q;
}

void Party::setMiles(int mile)
{
    miles = mile;
}

int Party::getMiles()
{
    return miles;
}
void Party::addMiles(int mile)
{
    miles = miles + mile;
}

int Party::randomNumbers(int min, int max)
{
    return (rand() % (max-min+1)) + min;
}

void Party::setBill(double cost)
{
    bill = cost;
}

double Party::getBill()
{
    return bill;
}
void Party::setWagonStatus(int wagon)
{
    wagonStatus = wagon;
}

string Party::getWagonStatus()
{
    return wagonStatus;
}

void Party::addFoodToBill(int quantity)
{
     bill = bill+(quantity*foodp);
}

void Party::addSuppliesToBill(int quantity)
{
     bill = bill + (quantity*partsp);
}

void Party::addAmmoToBill(int quantity)
{
    bill = bill + (quantity*ammop);
}

void Party::addMedsToBill(int quantity)
{
    bill = bill + (quantity*medicalp);
}

void Party::addPartsToBill(int quantity)
{
    bill = bill + (quantity*partsp);
}
