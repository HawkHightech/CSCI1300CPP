// Author: Alexander P. Hawkins CS1300 Spring 2018 
// Recitation: 104 Yichen Wang 
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn  
// Homework 8 - Oregon Trail

#include "Date.h"
#include <iostream>
#include <string>
using namespace std;

Date::Date(int month, int day)
{
    iMonth = month;
    iday = day;
}

void Date::setDate(int month, int day)
{
    iMonth = month;
    iday = day;
}

Date::~Date()
{
    //Deconstructor
}


int Date::getMonth()
{
    return iMonth;
}

int Date::getDay()
{
    return iday;
}
