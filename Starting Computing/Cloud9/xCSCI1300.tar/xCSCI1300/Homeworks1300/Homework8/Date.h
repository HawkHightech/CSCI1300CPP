// Author: Alexander P. Hawkins CS1300 Spring 2018 
// Recitation: 104 Yichen Wang 
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn  
// Homework 8 - Oregon Trail

#ifndef DATE_H
#define DATE_H
#include <iostream>
using namespace std;

class Date
{
    public:
        Date(int, int);
        ~Date();

        int getMonth();
        int getDay();
        
        void setDate(int, int);
        
    private:
        int months[9] = {3, 4, 5, 6, 7, 8, 9, 10, 11}; //March through November
        int iday;
        int iMonth;
};
#endif