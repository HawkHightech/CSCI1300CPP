// Author: Alexander P. Hawkins CS1300 Spring 2018 
#ifndef PARTY_H
#define PARTY_H

using namespace std;
class Party
{
    public:
        Party();
        ~Party();

        double getFoodp();
        void setFoodp(double);
        int getqFood();
        void buyFood(int);

        double getMoney();
        void setMoney(double);

        double getAmmop();
        void setAmmop(double);
        int getAmmoq();
        void setAmmoq(int);

        double getOxenp();
        void setOxenp(double);
        int getOxenq();
        void setOxenq(int);

        double getPartsp();
        void setPartsp(double);
        int getPartsq();
        void setPartsq(int);


        double getMedicalp();
        void setMedicalp(double);
        int getMedicalq();
        void setMedicalq(int);

        void setMiles(int);
        int getMiles();
        void addMiles(int);
        int randomNumbers(int, int);


        void setBill(double);
        double getBill();

        void setWagonStatus(int);
        string getWagonStatus();

        void addFoodToBill(int);
        void addSuppliesToBill(int);
        void addAmmoToBill(int);
        void addMedsToBill(int);
        void addPartsToBill(int);

    private:
        double foodp = .5;
        int qFood = 1;
        double ammop = 2;
        int ammoq = 20;
        double yokep = 40;
        int yokeq = 1;
        double partsp = 20;
        int partsq = 1;
        double medicalp = 25;
        int medicalq = 1;
        int miles = 0;
        double money = 1200;
        double bill = 0.0;
        string wagonStatus;
};

#endif // PARTY_H
