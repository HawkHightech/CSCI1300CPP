// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 6 - Problem 4

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

//Create a function named CheckPhrase
    //This function needs 6 input perameters
        //(1) A string phrase
        //(2) A string outputFile (the name of the file)
        //(3) An array of strings correctWords
        //(4) Size of the array correctWords
        //(5) A 2D array of strings MisspelledWords[][2]
        //(6) The number of rows in the MisspelledWords array
        
    //Open the file
    //If the phrase is empty
        //Display "Phrase is empty. Nothing to write in file." to the user
        //Return nothing
    //If the file opens
        //While the computer goes each line
        //We will call the function CheckWord
        //Erase part of the string
        //Write to the file
        //The file will close
        
void CheckPhrase(string phrase, string outputFile, string correctWords[], int size, string MisspelledWords[][2], int numRows) //The delcared function namedCheckPhrase with the 6 input perameters
{
    stringstream xx(phrase); //Input and output to a string
    ofstream file(outputFile, ios::app); //The syntax for writing to a file
    string line = ""; //The declared string variable named line that starts empty
    
    if (phrase == "") //If the phrase is empty
    {
        cout << "Phrase is empty. Nothing to write in file." << endl; //Display "Phrase is empty. Nothing to write in file." to the user
        return; //Return nothing
    }
    
    if (file.is_open()) //If the file does open
    {
        string blank = ""; //A declared string variable named blank and starting empty
        while (getline(xx, line, ' ')) //While the computer goes each line
        {
            blank += CheckWord(line, correctWords, size, MisspelledWords, numRows) + " "; //The variable blank is now the function of CheckWord
        }
        
        blank = blank.erase(blank.length()-1, 1); //Erases part of the string
        file << blank << endl; //Writing the blank variable to the file
        file.close(); //The file will close
    }
    
    return; //Return nothing
}