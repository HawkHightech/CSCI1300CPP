// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 6 - Problem 1

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

//Creat a function named ReadCorrectWords
    //Function needs to have four input perameters
        //(1) String filename (To open a file)
        //(2) String CorrectWords[] (Array)
        //(3) Size of the array (int size)
        //(4) Int startIndex (The index at which the computer should begin adding the words from the file into the array)
    
    //Open the file
    //If the file opens
        //While the computer is going through every line in the file
        //The first word in the file will go into the array starting at the index
        //The count (to get the amount of words that went into the array) will increase by 1
        //The computer will move into the next slot in the array
    //The file will close
    //The computer will return the amount of words that went into the array

int ReadCorrectWords(string filename, string correctWords[], int size, int startIndex) //A declared function named ReadCorrectWords with the four input perameters
{
    ifstream file; //The syntax to read a file
    file.open(filename); //Opening the file of the user's choice
    int count = 0; //A declared integer (int) variable named count starting at 0
    
    if (file.fail()) //If the file does not open
    {
        return -1; //Return -1
    }
    
    else if (startIndex >= size) //If the starting Index is equal to or greater than the size of the array
    {
        return -1; //Return -1
    }
    
    else if (file.is_open()) //If the file opens
    {
        string line = ""; //A declared string variable named line that in blank
        
        while (getline(file, line) && startIndex < size) //While the computer goes through every line in the file and the starting Index is less than the size of the array
        {
            correctWords[startIndex] = line; //The number of the starting Index will be the starting slot of the correctWords array
            startIndex++; //The startIndex will increase its number by 1
        }
        
        
        for (int i = 0; i < size; i++) //While a declared variable i is less than the size of the array
        {
            if (correctWords[i] != "") //If the index of the array is not blank
            {
                count++; //The count will increase by 1
            }
        }
        
        return count; //At the end of the while loop, the computer will return the amount of words that went into the array
        file.close(); //The file closes
        
    }
    
}