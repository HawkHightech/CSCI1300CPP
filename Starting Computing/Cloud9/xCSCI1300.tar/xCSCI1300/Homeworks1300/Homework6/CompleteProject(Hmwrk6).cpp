// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 6 - Complete Project

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

//Problem 1
//Creat a function named ReadCorrectWords
    //Function needs to have four input perameters
        //(1) String filename (To open a file)
        //(2) String CorrectWords[] (Array)
        //(3) Size of the array (int size)
        //(4) Int startIndex (The index at which the computer should begin adding the words from the file into the array)
    
    //Open the file
    //If the file opens
        //While the computer is going through every line in the file
        //The first word in the file will go into the array starting at the index
        //The count (to get the amount of words that went into the array) will increase by 1
        //The computer will move into the next slot in the array
    //The file will close
    //The computer will return the amount of words that went into the array

//Problem 2    
//Create a function named ReadMisspelledWords
    //This function needs four input perameters
        //(1) A string filename
        //(2) A 2D array of strings MisspelledWords[][2]
        //(3) The number of rows in the array MisspelledWord
        //(4) An integer startIndex
        
    //Open the file
    //If the file does open
        //Read the file line by line
        //The starting Index in the MispelledWords array will be the first word in the file
        //The computer looks at the second word through the end of the line
        //The starting Index in the MispelledWords array will be the second word in the file
        //The starting Index will increase by 1
        //The amount of word pairs in the array (count) will increase by 1
        //The function will return the amount of word pairs in the array

//Problem 3        
//Create a function named CheckWord
    //This function needs 5 input perameters
        //(1) A string word
        //(2) An array of strings correctWords
        //(3) Size of the array correctWords
        //(4) A 2D array of strings MisspelledWords[][2]
        //(5) The number of rows in the MisspelledWords array
        
    //The computer will look through the word
        //The computer will turn every letter in the word into lowercase letters
        //The word of given word will go into the correctWords array
        //Return the word
    //If the given word is found
        //Return the correct spelling of the word
        //Display "unknown" to the user

//Problem 4
//Create a function named CheckPhrase
    //This function needs 6 input perameters
        //(1) A string phrase
        //(2) A string outputFile (the name of the file)
        //(3) An array of strings correctWords
        //(4) Size of the array correctWords
        //(5) A 2D array of strings MisspelledWords[][2]
        //(6) The number of rows in the MisspelledWords array
        
    //Open the file
    //If the phrase is empty
        //Display "Phrase is empty. Nothing to write in file." to the user
        //Return nothing
    //If the file opens
        //While the computer goes each line
        //We will call the function CheckWord
        //Erase part of the string
        //Write to the file
        //The file will close

//Problem 5
//Create a function named CheckFile
    //This function needs 6 input perameters
        //(1) A string inputFile
        //(2) A string outputFile (the name of the file)
        //(3) An array of strings correctWords
        //(4) Size of the array correctWords
        //(5) A 2D array of strings MisspelledWords[][2]
        //(6) The number of rows in the MisspelledWords array
        
    //Open the file for reading
    //If the file opens
        //If a line in the file is not empty
            //We will call the function CheckPhrase
        //If the file does not open
            //Display "invalid" to the user

//Problem 1        
int ReadCorrectWords(string filename, string correctWords[], int size, int startIndex) //A declared function named ReadCorrectWords with the four input perameters
{
    ifstream file; //The syntax to read a file
    file.open(filename); //Opening the file of the user's choice
    int count = 0; //A declared integer (int) variable named count starting at 0
    
    if (file.fail()) //If the file does not open
    {
        return -1; //Return -1
    }
    
    else if (startIndex >= size) //If the starting Index is equal to or greater than the size of the array
    {
        return -1; //Return -1
    }
    
    else if (file.is_open()) //If the file opens
    {
        string line = ""; //A declared string variable named line that in blank
        
        while (getline(file, line) && startIndex < size) //While the computer goes through every line in the file and the starting Index is less than the size of the array
        {
            correctWords[startIndex] = line; //The number of the starting Index will be the starting slot of the correctWords array
            startIndex++; //The startIndex will increase its number by 1
        }
        
        
        for (int i = 0; i < size; i++) //While a declared variable i is less than the size of the array
        {
            if (correctWords[i] != "") //If the index of the array is not blank
            {
                count++; //The count will increase by 1
            }
        }
        
        return count; //At the end of the while loop, the computer will return the amount of words that went into the array
        file.close(); //The file closes
    }
    
}

//Problem 2
int ReadMisspelledWords(string filename, string MisspelledWords[][2], int numRows, int startIndex) //A declared function named ReadMisspelledWords with the four perameters
{
    ifstream file; //The syntax for the file to be read
    file.open(filename); //Opening the file
    string line = ""; //A string declared variable named line that is blank
    string strOne = ""; //A string declared variable named strOne that is blank
    
    if (startIndex >= numRows) //If the starting Index is greater than or equal to the number of rows in the array
    {
        return -1; //Return -1
    }
    
    if (file.is_open()) //If the file opens
    {
        while(getline(file, line, '\t') && startIndex < numRows) //While the computer looks through the file at each line and the starting Index is less than the number of rows in the array
        {
            MisspelledWords[startIndex][0] = line; //The starting Index in the MispelledWords array will be the first word in the file
            getline(file, strOne, '\n'); //The computer looks at the second word through the end of the line
            MisspelledWords[startIndex][1] = strOne; //The starting Index in the MispelledWords array will be the second word in the file
            startIndex++; //The starting Index will increase by 1
        }
        
        int count = 0; //Declaring an integer (int) variable named count starting at 0
        
        for (int i = 0; i < numRows; i++) //While the variable i is less than the number of rows in the array
        {
            if (MisspelledWords[i][0] != "") //If there is something in the array (MispelledWords) (Starting at the first slot)
            {
                count++; //The count will increase by 1
            }
        }
        
        return count; //Return the amount of word pairs in the array
    }
    
    else //Else
    {
        return -1; //Return -1
    }
}

//Problem 3
string CheckWord(string word, string correctWords[], int size, string MisspelledWords[][2], int numRows) //A declared variable named CheckWord with five input perameters
{
    for (int i = 0; i < word.length(); i++) //While the computer looks through the word
    {
        tolower(word[i]); //Turns the word into all lowercase letters
    }
    
    for (int i = 0; i < size; i++) //While the declared variable i is less than the size of the array
    {
        if (correctWords[i] == word) //The word of given word will go into the correctWords array
        {
            return word; //Return the word
        }
    }
    
    for (int i = 0; i < numRows; i++) //For the declared variable i is less than the number of rows
    {
        if (MisspelledWords[i][0] == word) //If the given word is found
        {
            return MisspelledWords[i][1]; //Return the correct spelling of the word
        }
    }
    
    return "unknown"; //Display "unknown" to the user
}

//Problem 4
void CheckPhrase(string phrase, string outputFile, string correctWords[], int size, string MisspelledWords[][2], int numRows) //The delcared function namedCheckPhrase with the 6 input perameters
{
    stringstream xx(phrase); //Input and output to a string
    ofstream file(outputFile, ios::app); //The syntax for writing to a file
    string line = ""; //The declared string variable named line that starts empty
    
    if (phrase == "") //If the phrase is empty
    {
        cout << "Phrase is empty. Nothing to write in file." << endl; //Display "Phrase is empty. Nothing to write in file." to the user
        return; //Return nothing
    }
    
    if (file.is_open()) //If the file does open
    {
        string blank = ""; //A declared string variable named blank and starting empty
        while (getline(xx, line, ' ')) //While the computer goes each line
        {
            blank += CheckWord(line, correctWords, size, MisspelledWords, numRows) + " "; //The variable blank is now the function of CheckWord
        }
        
        blank = blank.erase(blank.length()-1, 1); //Erases part of the string
        file << blank << endl; //Writing the blank variable to the file
        file.close(); //The file will close
    }
    
    return; //Return nothing
}

//Problem 5
void CheckFile(string inputFile, string outputFile, string correctWords[], int size, string MisspelledWords[][2], int numRows) //A created variable named CheckFile with six input perameters
{
    ifstream file(inputFile); //The syntax for reading the file
    string line = ""; //A delcared string variable named line that's starting blank
    
    if (file.is_open()) //If the file opens
    {
        while(getline(file, line)) //While the coputer looks through every line in the file
        {
            if (line != "") //If a line in the file is not empty
            {
                CheckPhrase(line, outputFile, correctWords, size, MisspelledWords, numRows); //Using the function CheckPhrase with CheckFile's input perameters
            }
        }
    }
    else //Else
    {
        cout << "invalid" << endl; //Display "invalid" to the user
    }
    
    return; //Return
    
}