// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 6 - Problem 2

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

//Create a function named ReadMisspelledWords
    //This function needs four input perameters
        //(1) A string filename
        //(2) A 2D array of strings MisspelledWords[][2]
        //(3) The number of rows in the array MisspelledWord
        //(4) An integer startIndex
        
    //Open the file
    //If the file does open
        //Read the file line by line
        //The starting Index in the MispelledWords array will be the first word in the file
        //The computer looks at the second word through the end of the line
        //The starting Index in the MispelledWords array will be the second word in the file
        //The starting Index will increase by 1
        //The amount of word pairs in the array (count) will increase by 1
        //The function will return the amount of word pairs in the array
        

int ReadMisspelledWords(string filename, string MisspelledWords[][2], int numRows, int startIndex) //A declared function named ReadMisspelledWords with the four perameters
{
    ifstream file; //The syntax for the file to be read
    file.open(filename); //Opening the file
    string line = ""; //A string declared variable named line that is blank
    string strOne = ""; //A string declared variable named strOne that is blank
    
    if (startIndex >= numRows) //If the starting Index is greater than or equal to the number of rows in the array
    {
        return -1; //Return -1
    }
    
    if (file.is_open()) //If the file opens
    {
        while(getline(file, line, '\t') && startIndex < numRows) //While the computer looks through the file at each line and the starting Index is less than the number of rows in the array
        {
            MisspelledWords[startIndex][0] = line; //The starting Index in the MispelledWords array will be the first word in the file
            getline(file, strOne, '\n'); //The computer looks at the second word through the end of the line
            MisspelledWords[startIndex][1] = strOne; //The starting Index in the MispelledWords array will be the second word in the file
            startIndex++; //The starting Index will increase by 1
        }
        
        int count = 0; //Declaring an integer (int) variable named count starting at 0
        
        for (int i = 0; i < numRows; i++) //While the variable i is less than the number of rows in the array
        {
            if (MisspelledWords[i][0] != "") //If there is something in the array (MispelledWords) (Starting at the first slot)
            {
                count++; //The count will increase by 1
            }
        }
        
        return count; //Return the amount of word pairs in the array
    }
    
    else //Else
    {
        return -1; //Return -1
    }
}