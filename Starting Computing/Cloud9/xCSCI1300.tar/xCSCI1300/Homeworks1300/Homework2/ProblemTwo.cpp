// Author: CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 2 - Problem 2

//Calculate how many seconds are in a day
//Calculate how many seconds are in an hour
//Calculate how many seconds are in a minute
//For the number we want to calculate,
  //Take the remainder of that number to calculate the days
  //The remainder of that number will display the result through a 24-hour clock
  //Keep getting the remainder for days, hours, minutes, and seconds
//Display the results for days, hours, minutes, and seconds


#include <iostream>
using namespace std;

void howLong(int seconds)
{

    int days = seconds / 86400; //The number of seconds that are in a day
    int remainder_days = seconds % 86400; //The remainder of days through the perameter
    
    int hours = remainder_days / 3600; //The remainder of days divided by how many seconds are an hour
    int remainder_hours = seconds % 3600; //The remainder of hours through the perameter
    
    int minutes = remainder_hours / 60; //The remainder of hours divided by how many seconds are in one minute
    int remainder_minutes = seconds % 60; //The remainder of minutes of minutes through the perameter
  
  cout << seconds << " seconds is " << days << " days, " << hours << " hours, " << minutes << " minutes, and " << remainder_minutes << " seconds." << endl;
  // ^ The result that needs to be displayed
}


int main()
{
  
    howLong(70000); //Test Case #1
    howLong(12345); //Test Case #2
    howLong(13597); //Test Case #3
    
}
