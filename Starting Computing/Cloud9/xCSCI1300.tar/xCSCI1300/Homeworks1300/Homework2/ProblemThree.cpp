// Author: CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 2 - Problem 3


//Create a function called Carnot with two Perameters (TC and TH)
    //TC and TH are integers
        //Note: When dividing TC and TH, the result needs to be a decimal
    //Use the equation given into the computer
    //Return the result of the given equation
    


#include <iostream>
using namespace std;

double carnot(int TC, int TH) //Two perameters for the absolute temperatures. Numbers into the perameters are Integers.
{
    double n; //Decimal result for the given equation.
    n = 1 - ( TC / double(TH)); //The given equation. Dividing by two integers will give an integer value but I need a 
    //decimal value (double or float).
    return n; //Return the value of the equation.
    
}

int main()
{
    
    cout << carnot(160, 1160) << endl; //Test Case #1
    cout << carnot(105, 1011) << endl; //Test Case #2
    cout << carnot(13, 2502) << endl; //Test Case #3
    
}