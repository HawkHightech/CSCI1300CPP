// Author: CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 2 - Problem 1

//Goal: Finding the US Population in one year (365 days)
//Rate of change:
    //Birth = Every 8 seconds (+1 human)
    //Death = Every 12 seconds (-1 human)
    //New Immigrant = Every 33 seconds (+1 human)
//1 day = 86400 seconds
//Total seconds in a year = 31536000
//8 (seconds) * 10800 = 86400 (one day)
//12 (seconds) * 7200 = 86400 (one day)
//33 (seconds) * 2618 = 86400 (one day)
//Make Birth, Death, and New Immigrant all variables
//Add Birth, Subtract Death, and Add Immigrant
//Add the current population to the result of Birth, Death, and New Immigrant. Make this a new variable
//Return the new variable of all of the populations.

#include <iostream>
using namespace std;

int population (int current_pop)
{
    int secs_in_year = 31536000; //The total number of seconds that are in a year
    
    int birth_secs = secs_in_year / 8; //The total number of Births in a year
    int death_in_secs = secs_in_year / 12; //The total number of Deaths in a year
    int ni_in_secs = secs_in_year / 33; //The total number of New Immigrants in a year
    
    int new_current = current_pop + (birth_secs) - (death_in_secs) + (ni_in_secs); //The New Current Population is what you input
    // as your population at first added to the Birth (Human on earth) subtracted by your Death (Human not on earth) added to
    // the New Immigrant (Human on earth)
    return new_current; //Output the New Current Population
}

int main()
{
    cout << population(1000000) << endl; //Inputing current population into the Population Parameter (Test Case #1)
    cout << population(5725913) << endl; //Test Case #2
    cout << population(4735913) << endl; //Test Case #3
    
    
}