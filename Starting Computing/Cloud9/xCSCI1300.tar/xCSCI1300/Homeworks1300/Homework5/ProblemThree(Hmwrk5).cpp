// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 5 - Problem 3

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

//Create a function named normalize
    //The function will intake two perameters
        //(1) The samples array
        //(2) The size of the array
        
    //While the computer goes through the array
        //The computer need to find the biggest number in the array and store it into a variable
    //Once the biggest number is found
        //The biggest number will be multiplied by the fixed number (36773) as well as divided by the biggest number in the array
    //The function will display the new numbers in the array

void normalize (int samples[], int size) //A created function named normalize with two perameters
{
    int var = 0; //A created variable named var starting at 0
    
    for (int i = 0; i < size; i++) //While a number is less than the size
    {
        if (samples[i] > var) //If the number in the sample is greater than the created variable var
        {
            var = samples[i]; //Var is now not 0, but the new number in the array
        }
    }
    
    for (int n = 0; n < size; n++) //While a number is less than the size
    {
        samples[n] = (samples[n] * 36773) / var; //The new numbers in the array are the numbers in the array * 36773 / var
    }
}