// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 5 - Problem 2

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

//Create a function named add_echo with four perameters
    //(1) A samples array
    //(2) The size of the samples array
    //(3) The sampling rate (as an Int)
    //(4) The delay d in seconds (as a double)
    
    //The function needs to multiply the sample rate and the delay (d)
    //There needs to be a new array that needs to be created
    //The computer will take the number that is given with the sample rate * delay and start at that index
    //The computer will take the first number in the array and add it to whichever the index is for sample rate * d
    //The computer will continue the process until the array is over
    //Those numbers will be stored into the new array
    //The function will display the new array

void add_echo (int samp_arr[], int size, int samp_rate, double d) //The created function named add_echo with the four perameters
{
    int samp_d = samp_rate * d; //A created variable named samp_d thta multiplies the sample rate & the delay
    int Samp[size]; //The new sample array
    
    for (int n = 0; n < size; n++) //While a number is less than the size
    {
        Samp[n] = samp_arr[n]; //The index of the new sample array is the index of the old sample array
    }
    
    for (int i = 0; i < size - samp_d; i++) //While a number is less than the size subtracted by the created variable samp_d
    {
        samp_arr[samp_d + i] = samp_arr[samp_d + i] + Samp[i]; //The index of the old sample array is the index number (given samp_d) + the index of the new array
    }
    
}