// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 5 - Problem 1

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

//Create a function named reverse
    //Function needs to have two perameters
        //(1) An array perameter
        //(2) An int perameter for the size
        
    //While an variable is increasing and is less than the size
        //The index of the original sample will be the number of a temporary sample
        //The index in the sample will be the size as well as the number of the variable
        //The new number in the sample will be the number of the temporary sample
    //The function will display the array backwards

void reverse(int samples[], int size) //The function named reverse with the 2 perameters
{
    for (int i = 0; i < (size/2); i++) //While the computer goes through the array
    {
        int temp_samples = samples[i]; //The index in the sample is a new number named temp_samples
        samples[i] = samples[(size - 1) - i]; //The index of the sample is the size-1 - the variable i
        samples[(size - 1) - i] = temp_samples; //The new array will be the number of the temporary number
    }
}