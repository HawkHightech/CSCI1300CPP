// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 7 - Problem 1

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
//#include "MyClass.h"
using namespace std;

class Book //Creating a class named Book
{
  public:
    Book(string, string); //A function named Book with two perameters
    Book(); //A function named Book
    ~Book(); //A function named Book
    string getTitle(); //A function named getTitle
    void setTitle(string); //A function named setTitle
    string getAuthor(); //A function named getAuthor
    void setAuthor(string); //A function named setAuthor
  
  
  private:
    string title = "NONE"; //A variable named title with string none
    string author = "NONE"; //A variable named author with string none
    
};

Book :: Book(string Btitle, string Bauthor) //Creating the function Book
{
    title = Btitle; //variable title is a new title
    author = Bauthor; //variable author is new author
}

Book::Book() //Creating the function Book
{
    
}

Book :: ~Book() //Creating the function Book
{
    
}

void Book :: setTitle(string Btitle) //Creating the function setTitle
{
    title = Btitle; //Variabe title is new title
}

string Book :: getTitle() //Creating the function getTitle
{
    return title; //return the title
}

void Book :: setAuthor(string Bauthor) //Creating the function setAuthor
{
    author = Bauthor; //Variable author is new author
}

string Book :: getAuthor() //Creating the function getAuthor
{
    return author; //return author
}