// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Homework 7 - Problem 2

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
//#include "MyClass.h"
using namespace std;

class User //Creating a class named user
{
    private:
    string name; //Declaring string named name
    int rating[100]; //Declaring array named rating with 101 spaces
    int numRating; //Declaring int named numRating
    
    public:
    string getName(); //Declaring function string named getName
    void setName(string); //Declaring function void named setName
    int getRatings(); //Declaring function int named getRating
    void setRatings(int); //Declaring function void named setRatings
    int getNumRatings(); //Declaring function int named getNumRatings
    void setNumRatings(int); //Declaring function void named setNumRatings
    int getRatingAt(int index); //Declaring funciton int named getRatingAt
    int setRatingAt(int index, int number); //Declaring function int named setRatingAt
    
    
    User(string newName, int userRatings[], int numberRatings); //Declaring function named User with three perameters
    User(); //Declaring function named User with no perameters
};

User::User(string newName, int userRatings[], int numberRatings) //Creating function named User with the three perameters
{
    name=newName; //Variable name is new name
    numRating=numberRatings; //Variable numRating is the new number rating
    
    for(int i =0;i<100;i++) //While the computer goes through the the rating array
    {
        rating[i]=userRatings[i]; //The user Ratings are placed into the rating array
    }
}

User::User() //Creating a function named user
{
    name="NONE"; //name is none
    numRating=0; //The rating begins at 0
    
    for(int i=0;i<100;i++) //While the computer is going through the array
    {
        rating[i]=0; //The index at the rating array is 0
    }
}

string User::getName() //Creating the function getName
{
    return name; //return name
}

void User::setName(string newName) //Creating the function named setName with one perameter
{
    name=newName; //The variable name is the new given name
}

int User::getNumRatings() //Creating the function named getNumRatings
{
    return numRating; //return numRating
}

void User::setNumRatings(int numberRatings) //Creating the function named setNumRatings with one perameter
{
    numRating=numberRatings; //The variable numRating is the new number ratings
}

int User::getRatingAt(int index) //Creating a function amed getRatingAt with one perameter
{
    if(index >= numRating) //If the index is greater than or equal to the numRating
    {
        return -1000; //return -1000
    }
    
    else //else
    {
        return rating[index]; //return the index of the rating
    }
}

int User::setRatingAt(int index, int number) //Creating the variable named setRatingAt with two perameters
{
    if(index >= numRating) //If the index is greater than or equal to the numRating
    {
        return -1000; //return -1000
    }
    
    if (number!=-5 && number!=-3 && number!=0 && number!=1 && number!=3 && number!=5) //If the the given number does not equal -5,-3,0,1,3,& 5
    {
        cout<<"Invalid Input!"<<endl; //Display "Invalid input" to the user
        return -1; //return -1
    }
    
    else //else
    {
        cout<<"Success!"<<endl; //Display "Success!" to the user
        rating[index] = number; //The index of the rating array is the given number
        return 0; //return 0
    }
}