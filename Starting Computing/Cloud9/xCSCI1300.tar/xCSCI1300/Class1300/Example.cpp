#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    int num;
    double mySqrt;
    
    cout << "Enter the number you want to Square Root: " << endl;
    cin >> num;
    
    while (num < 0);
        {
            cout << "Needs to be a Positive Number. Please Try again." << endl;
            
            cout << "Enter the number you want to Square Root: " << endl;
            cin >> num;
        }
    if (num = 0)
        {
            num = 1;
        }
    
    mySqrt = pow(num, 0.5);
    
    cout << "Your number is " << num << endl;
    cout << "The Square Root is " << mySqrt << endl;
}

