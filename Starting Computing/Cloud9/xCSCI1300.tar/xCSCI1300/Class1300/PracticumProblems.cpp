// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Practice

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
//#include "MyClass.h"
using namespace std;

//Problem 1
void printAsterisks()
{
    for (int i = 0; i < 3; i++)
    {
        for (int n = 0; n < 4; n++)
        {
            cout << "*";
        }
        cout<< endl;
    }
}

//Problem 2
void printPlus()
{
    for (int i = 0; i < 4; i++)
    {
        for (int n = 0; n < 3; n++)
        {
            cout << "+";
        }
        
        cout << endl;
    }
}

//Problem 3
void printOddPattern()
{
    for (int i = 0; i < 3; i++)
    {
        cout << "$*$*$" << endl;
    }
}

//Problem 4
int MultiplicationTableFor()
{
    for (int row = 1; row <= 5; row++)
    {
        for (int column = 1; column <= row; column++)
        {
            cout << row * column << " ";
        }
        cout << endl;
    }
}

//Problem 5
int MultiplicationTableWhile()
{
    int row = 1;
    
    while (row <= 5)
    {
        int column = 1;
        
        while (column <= row)
        {
            cout << row * column << " ";
            column++;
        }
        cout << endl;
        row++;
    }
    
}

//Problem 6
bool validateEmail(string str)
{
    int countOne = 0;
    int countTwo = 0;
    string com = ".com";
    
    for (int i = 0; i < str.length(); i++)
    {
        if (str[i] == '@')
        {
            countOne++;
        }
        
        if (str.substr(i,com.length()) == com)
        {
            countTwo++;
        }
    }
    
    if (countOne == 1 && countTwo == 1)
    {
        return true;
    }
    
    else
    {
        return false;
    }
}

//Problem 7
bool validateEmail(string str)
{
    int i = 0;
    int countOne = 0;
    int countTwo = 0;
    string com = ".com";
    
    while (i < str.length())
    {
        
        if (str[i] == '@')
        {
            countOne++;
        }
        
        if (str.substr(i,com.length()) == com)
        {
            countTwo++;
        }
        
        i++;
    }
    
    if (countOne == 1 && countTwo == 1)
    {
        return true;
    }
    
    else
    {
        return false;
    }
}

//Problem 8
int countPrimes(int array[], int size)
{
    int prime = 0;
    
    for (int i = 0; i < size; i++)
    {
        int count = 0;
        for (int n = 2; n <= array[i]; n++)
        {
            if(array[i] % n == 0)
            {
                count++;
            }
        }
        
        if (count == 1)
        {
            prime++;
        }
        
    }
    return prime;
}

//Problem 9
void printTotalMedals(string sport[], int gold[], int silver[], int bronze[], int size)
{
    if (size < 1)
    {
        cout << "Invalid size. Size must be at least 1." << endl;
    }
    
    for ( int i = 0; i < size; i++)
    {
        cout << sport[i] << ": " << gold[i] + silver[i] + bronze[i] << endl;
    }
}

//Problem 10
int countCharacter(string array[], int size, char ch)
{
    string sentence = "";
    string word = "";
    int count = 0;
    
    for (int i = 0; i < size; i++)
    {
        word = array[i];
        sentence = sentence + word;
    }
    
    for (int n = 0; n < sentence.length(); n++)
    {
        if (sentence[n] == ch)
        {
            count++;
        }
    }
    
    return count;
}

//Problem 11
int PrintStudents(string infilename, int minscore, string outfilename)
{
    ifstream inputfile;
    inputfile.open(infilename);
    ofstream outputfile;
    outputfile.open(outfilename);
    
    int count = 0;
    string words[100];
    int startIndex = 0;
    
    if (inputfile.fail() || outputfile.fail())
    {
        return -1;
    }
    
    while(! inputfile.eof() && startIndex < 100)
    {
        string line = "";
        getline (inputfile, line);
        line = line + ',';
        split (line, ',', words, 100);
        if (stoi(words[1]) >= minscore)
        {
            outputfile << words[0] << ", " << words[2] << endl;
        }
        count++;
    }
    
    outputfile.close();
    inputfile.close();
    return count;
    
}

//Problem 12
int writeCountryDensity(string infilename, int minscore, string outfilename)
{
    ifstream inputfile;
    inputfile.open(infilename);
    ofstream outputfile;
    outputfile.open(outfilename);
    int count = 0;
    
    if (inputfile.fail() || outputfile.fail())
    {
        return -1;
    }
    string words[100];
    int startIndex = 0;
    while (! inputfile.eof() && startIndex < 100)
    {
        string line = "";
        getline (inputfile,line);
        if (line.length() == 0)
        {
            break;
        }
        split(line, ',', words, 100);
        if (stoi(words[1])/stof(words[2]) <= minscore)
        {
            outputfile << words[0] << ", " << stof(words[1])/stof(words[2]) << endl;
            count++;
        }
    }
    
    outputfile.close();
    inputfile.close();
    return count;
}


//Problem 13
int findDuplicate(int array[], int size)
{
    int count = 0;
    
    for (int i = 0; i < size; i++)
    {
        for (int n = i+1; n < size; n++)
        {
            if (array[i] == array[n])
            {
                cout<< array[i];
                count++;
            }
        }
    }
    
    if (count == 0)
    {
        cout << -1;
    }
}