// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Practice (Instructor)

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

int main()
{
    
}