// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 4 - Problem 1

#include <iostream>
using namespace std;

//In need of Two perameters for the function calcPay
    //One perameter named hours worked (Needs to be a floating point)
    //Second perameter named pay rate (Needs to be a floating point)

//Do not print "How many hours did you work?"
//Do not print "What's your hourly pay?"
//Function needs to print the Calculated Pay of how many hours * your hourly pay
//If you've worked over 40 hours, you worked in overtime
    //The overtime pay is your hourly pay * 1.5 (Time and a half)

void calcPay (float hours, float hourly_pay) //Function calcPay with both perameters (in order)
{
    if ((hours >= 0) && (hours <= 40) && (hourly_pay >= 0)) //If you've worked between 0-40 hours then you're also getting paid hourly
    {
        float Reg_pay; // Declaring your regualr pay (not into overtime [Needs to be a float])
        Reg_pay = hours * hourly_pay; //Hours you've worked * How many hours you've worked = Your regular pay
        cout << "Your pay is $" << Reg_pay << "." << endl; //Displays your Regular pay (Didn't hit the overtime mark)
    }
    
    else if ((hours > 40) && (hourly_pay >= 0)) //If you've worked hard to get over 40 hours then you're also getting paid hourly
    {
        float overtime; //Declaring your overtime pay (Needs to be a float)
        overtime = (40 * hourly_pay) + (hours - 40) * (hourly_pay * 1.5); //How many hours you've worked * your hourly pay +
        // How many hours you've worked overtime * Your hourly pay * A time & a Half
        cout << "Your pay is $"<< overtime << "." << endl; //Displays your Regular Pay + Overtime
    
    }
    
    else //If the values do not exceed
    {
        cout << "Pay rate and hours worked cannot be negative values." << endl; //Try again
    }
    
}

int main()
{
    calcPay(10, 10); //Test case 1
    calcPay(15, 20); //Test case 2
    calcPay(25, 30); //Test case 3
}