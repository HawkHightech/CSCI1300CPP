// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 4 - Problem 3

#include <iostream>
using namespace std;

//Create a function named printEvenNums
    //Function needs to have one perameter (Perameter needs to be an integer)
    //Function should not return anything

//Create a counter that increases
//While the counter is less than or equal to the max, print the value of that counter
    //Once the counter is equal to or greater than the max, the while loop will end
    //Do not return anything
    

void printEvenNums(int max) //Function named printEvenNums (Integer Perameter named Max)
{
    int num; //Delcaring an integer named num (counter)
    num = 2; //Num starts at the value 2
    
    while (num <= max) //While num (counter) is less than or equal to the max
    {
        cout << num << endl; //Print the value of the counter (num)
        num = num + 2; //Increase the counter number by +2 to get all even numbers
    }
}

int main()
{
    int max; //Declaring an integer named max
    
    cout << "Enter an integer: " << endl; //Displays what I want the user to input
    cin >> max; //The user's input is gathered into the system's storage
    
    printEvenNums(max); //Run the function with the user's input
}
