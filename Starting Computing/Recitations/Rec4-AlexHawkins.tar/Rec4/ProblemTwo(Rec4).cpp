// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 4 - Problem 2

#include <iostream>
using namespace std;

//Goal: I want the next calculated value in the Collatz Sequence
//Need a function named Collatz Step
    //Needs to have one integer perameter
    
//If the given input is even
    //Use the equation n/2
    
//If the given input is odd
    //Use the equation 3n + 1
    
//If the given value is not positive
    //Return 0;

int collatzStep(int n) //Function named collatzStep with one perameter (Needs to be an integer)
{
    int b; //Declaring an integer
    
    if ((n >= 0) && (n % 2 == 0)) //If your given number is greater than 0 & an even number
    {
        b = n / 2; //Use the equation n/2 & equal the equation to the declared integer
        return b; //Return the final result of the equation
    }
    
    if ((n >= 0) && (n % 2 != 0)) //If your given number is greater than 0 & an odd integer
    {
        b = (3 * n) + 1; //Use the equation 3n+1 & set the equation equal to the declared integer
        return b; //Return the final result of the equation
    }

        return 0; //Return O;
}

int main()
{
    collatzStep(10); //Test case 1
    collatzStep(20); //Test case 2
    collatzStep(30); //Test case 3
}