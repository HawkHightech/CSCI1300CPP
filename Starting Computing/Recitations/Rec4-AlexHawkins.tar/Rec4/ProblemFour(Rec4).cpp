// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 4 - Problem 4

#include <iostream>
using namespace std;

//Create a function called printMultiples
    //Needs to have two integer Perameters
        //First integer perameter needs to be the multiple
        //Second integer perameter needs to be the max value

//Function needs to have a counter
    //Counter will go up by 1
//Multiple * Counter = Your New Number
    //This new number cannot be over the max value
    //If the new number exceeds the max value,
        //The function is over
        
    //The ending calculation needs to print the all the positive integer multiples of the first integer perameter 
    //^+ less than or equal to the max value
    
    //Do not return anything (void)

void printMultiples(int multiples, int max) //Function called printMultiples (Two integer perameters)
{
    int constant = 1; //The Declared Integer Counter that starts at 1 (constant)
    int new_num; //Declared integer for the New Value
    
    while (new_num <= max) //While your new number is less than or equal to your max value
    {
        new_num = multiples * constant; //Your new number = What the user wants to multiply by * the counter (constant)
        if (new_num <= max) //However, if the new number is less than or equal to the max value
        {
            cout << new_num << endl; //Print the new number value
            constant ++; //Counter (constant) will go up by +1
        }    
    }
    
}

int main()
{
    int max; //Declared Integer named Max (Needed for printMultiples perameter)
    int multiples; //Declared Integer named Multiples (Needed for printMultiples perameter)
    
    cout << "Enter your max integer: " << endl; //Displays what I want the user to input
    cin >> max; //The user's input is gathered into the system's storage
    
    cout << "Enter the multiple: " << endl; //Displays what I want the user to input
    cin >> multiples; //The user's input is gathered into the system's storage
    
    printMultiples(multiples,max); //The created function begins
    
}