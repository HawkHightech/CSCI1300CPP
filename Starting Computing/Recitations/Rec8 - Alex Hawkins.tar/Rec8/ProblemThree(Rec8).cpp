// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 8 - Problem 3

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
using namespace std;

//Create a function named fileLoadRead
    //The function needs only one perameter
        //(1) The name of the file that I'm reading to
    
    //If the file does not open/exist
        //Return -1
    //If the file does exist but there is nothing in the file
        //Return 0
    //If the file does exist and there is stuff in the file
        //Get each line in the file
        //Return the amount of times the computer gets the line
        //Close the file
        
int fileLoadRead(string filename) //The created function named fileLoadRead with one perameter
{
    ifstream file; //The syntax to read a file
    file.open(filename); //Opening the file that the user is looking for
    string line = ""; //A declared string variable named line that is blank
    int count = 0; //A declared integer (int) variable named count that starts at 0
    
    if (file.is_open()) //If the file opens
    {
        while (getline(file, line)) //While the computer looks at each line in the file
        {
            count++; //The count will increase by 1
        }
        
        file.close(); //The file closes (when the while loop ends, the file is done being examined and the file closes)
        return count; //Return how many lines that were in the file
    }
    
    else //If the file does not open
    {
        return -1; //Return -1
    }
}

int main() //Int Main
{
    cout << fileLoadRead("myFile.txt") << endl; //Test case
}