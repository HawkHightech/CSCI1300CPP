// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 8 - Problem 5

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
using namespace std;

//Create a function named saveData
    //This function needs four input perameters
        //(1) The filename
        //(2) An array of strings
        //(3) An integer 'n' which represents the number of values in the array
        //(4) The size of the array
    
    //If the file opens
        //The data in the array need to be changed from a string into a double (atof or stod) (Not incuding the Name)
        //The numbers that are converted from a string to a double need to be added to each other
        //When the numbers are added to each other, they need to be divided by however many numbers that were converted (Average)
    //The result needs to display the given name "Name: " and the Average "Avg: "
    
    
void saveData(string fileName, string data[], int n, int size) //The created function named saveData with four input perameters
{
     ofstream file; //The syntax to write to a file
     file.open(fileName); //Opening the file name
     double num = 0; //A declared double variable named num starting at 0
     double finalnum = 0; //A declared double variable named finalnum starting at 0
     double convert = 0; //A declared double variable named convert starting at 0
     
     if (file.is_open()) //If the file opens
     {
        
        for (int i = 0; i < n; i++) //While the declared variable i is less than the number of values in the array
        {
            convert = stod(data[i]); //The data in the array is being converted from a string to a decimal point
            
            num = num + convert; //The numbers in the array are being added to each other
                
        }
        
        finalnum = num / n; //The average is the numbers that were being added divided by the number of values in the array
        
        if (n > 0) //If the number of values in the array are greater than 0
        {
            file << "Name: " << data[n] << endl; //Write "Name: " & the given name in the new file
            file << "Avg: " << finalnum << endl; //Write "Avg: " & the average (finalnum) in the new file
        }
        
        else if (n < 0) //If the number of values in the array are less than 0
        {
            cout << "" << endl; //Display nothing because there is nothing in the array to display
        }
        
     }
     
}