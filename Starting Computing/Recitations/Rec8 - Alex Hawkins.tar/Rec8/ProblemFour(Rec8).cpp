// Author: Alexander P. Hawkins CS1300 Spring 2018
// Recitation: 104 Yichen Wang
// Cloud9 Workspace Editor Link: https://ide.c9.io/xoxvn/csci1300_xoxvn
// Recitation 8 - Problem 4

#include <iostream>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
using namespace std;

//Create a function named getLinesFromFile
    //The function needs three input perameters
        //(1) A string FileName
        //(2) A string array wordArray
        //(3) An integer sizeArray
    
    //Open the file in read mode
    //Read each line in the file
    //Store each line in the array
    //Return the number of lines placed in the array
    //Note:If there is an empty line, it will not be included in the array
    
int getLinesFromFile(string filename, string wordArray[], int sizeArray) //The created function named getLinesFromFile with the three input perameters
{
    ifstream file; //The syntax to read a file
    file.open(filename); //Opening the file of the user's choice
    string line = ""; //A declared string variable named line that in blank
    int i = 0; //A declared integer (int) variable named i starting at 0
    int count = 0; //A declared integer (int) variable named count starting at 0
    
    if (file.is_open()) //If the file opens
    {
        while (getline(file, line)) //While the computer looks through each line in the file
        {
            if (line == "") //If the line in the file is empty
            {
                i = i; // i will stay the same
            }
            
            else //If there is some type of content in a line of the file
            {
                wordArray[i] = line; //The index in the array is being filled with the line in the file
                i++; //i will increase by 1
                count++; //The count will increase by 1
            }
            
        }
        return count; //Returns how many lines are in the file
    }
    
    else //If the file does not open
    {
        return -1; //Return -1
    }
}

int main() //Int Main
{
    string wordArray[] = {"sky","night","78","ski season"};
    cout << getLinesFromFile("myFile.txt", wordArray, 4);
}